# PRD — "Transpose" Feature for the NTCCA Music App

**Feature name:** Transpose — Instrument & Voice Transposer
**Prepared for:** NTCCA Music App (build conversation)
**Status:** Ready to implement — all production code included below
**Origin:** Built and verified as a standalone app; this document packages it as a feature drop-in for the NTCCA app.

---

## 1. The one-sentence pitch

> **The piano is a C instrument. Its key is the key of the music. This feature shows what every instrument and voice plays from there.**

Born from a real church-musician question: *"If the piano is playing in A, my saxophone player would be playing in B, correct?"* (Yes — B for tenor/soprano/trumpet, F♯ for alto.)

## 2. Who it's for

Church music directors, pianists, worship leaders, and band leaders who need to answer, in seconds, on their phone, mid-rehearsal: *"What does the trumpet play? What note does the alto sax take in this 9 chord? What does the tenor sing?"*

## 3. What it does (feature list)

### 3.1 One instrument to another (the sentence UI)
- **Horn language, not chord language** — in Chord mode a horn/voice member's headline answer is their single written note (never "E9" — horns don't play stacks), with a piano cross-reference line: e.g. tenor shows "G♭ — You play G♭ — the 5 of the chord B9 · Piano plays E". That's the argument-ender between the horn and the keys: both sides see their own note AND the matching piano note.
- **One unified band flow** — a single sentence ("If the [piano ▾] is playing [A ▾]…") drives the whole band below it; the tenor sax is simply band member #1 (changeable), and "+ Add player" grows the same band without limit
- **The band on the staff** — a real treble-clef staff under the band showing the full chord voicing at concert pitch; every notehead is colored by the player who owns that tone (first-come-first-serve by join order), and chord players (keys/strings) get a royal-blue "plays the whole chord" bracket
- Two instrument/voice pickers embedded in a sentence: **"If the [Piano ▾] is playing [A], the [Tenor Saxophone ▾] plays [B]"** — both pickers swappable to any of ~56 instruments/voices. Defaults: Piano → Tenor Saxophone.
- Four modes: **Major key** (answer includes key signature, e.g. "B major · 5 sharps"), **Minor key**, **Chord** (power chords, triads, 7ths, 9ths, 13ths, etc. — 17 qualities, correctly spelled chord tones like C9 = C·E·G·B♭·D), **Note**.
- 12-note tap grid for the root; ♭/♯ spelling toggle.
- Big answer display with the target instrument's plain-English rule ("Sounds a major 9th lower than written") and, when the source isn't piano, the concert-pitch equivalent ("which is concert A").

### 3.2 Build the band
- Add **unlimited** instruments/voices from a dropdown; duplicates auto-number (Lead Vocal #1, #2).
- Source selector: default **"The piano — C instrument"**, or any band member's written part (for when there's no piano — e.g. horns working from the alto's part).
- Pick the key or chord type once → every player's part appears: **chord instruments** (piano, organ, guitar, bass, uke, mallets…) get the full chord; **horns and voices get ONE note** of the chord, each with a per-player **"Plays the…"** dropdown to reassign the chord tone (root, 3rd, 5th, ♭7…).
- Smart default voicing: lead/soprano → root, alto/trumpet → 3rd, tenor sax → 5th, bari/bass → ♭7.

### 3.3 Discoverability & teaching
- Blue "( tap to change )" markers + chevrons on every dropdown, numbered instruction strips per section, and a guided tour video (real screen recording of the app with a finger dot and captions — see §7 recipe).

## 4. Instrument coverage (56 voices/instruments)

SATB + lead vocal; soprano/alto/tenor/bari/C-melody saxes; trumpets C/B♭/D/E♭, cornet, flugelhorn, French horn F, alto horn E♭, trombones, euphonium (TC & BC), tuba; flute/piccolo/alto flute/bass flute, oboe/oboe d'amore/English horn, clarinets B♭/A/E♭/alto/bass, bassoon/contrabassoon, recorder; violin/viola/cello/double bass, guitar/bass/ukulele/mandolin/banjo; piano/organ/harp/accordion/celesta; glockenspiel/xylophone/marimba/vibraphone; timpani.

## 5. Transposition math (the contract)

- Pitch classes: **C=0, C♯/D♭=1 … B=11**.
- Every instrument carries `offset` where **written = concert + offset (mod 12)**:
  - C instruments & SATB: 0 · B♭ (trumpet, tenor/soprano sax, clarinet): +2 · E♭ (alto/bari sax, alto clarinet): +9 · F (French horn, English horn): +7 · A (clarinet in A, oboe d'amore): +3 · G (alto flute): +5 · D (trumpet in D): +10.
- **written = transpose(concert, inst, toWritten=true); concert = transpose(written, inst, false).**
- Chord tone spelling is **diatonic** (letter steps), so dominants spell ♭7 not ♯6.
- Key signatures: circle-of-fifths tables for major and minor (explicit `MINOR_FIFTHS` table — do not derive minor from relative major; that was a real bug).

## 6. File 1 — `src/lib/music.ts` (complete engine + data, drop in as-is)

```ts
// ── Transposition engine ──────────────────────────────────────────────
// Convention: written pitch class = (concert pitch class + offset) mod 12.
// Pitch classes: C=0, C#/Db=1, D=2, D#/Eb=3, E=4, F=5,
// F#/Gb=6, G=7, G#/Ab=8, A=9, A#/Bb=10, B=11

export type FamilyId =
  | 'voice'
  | 'sax'
  | 'brass'
  | 'woodwind'
  | 'strings'
  | 'keys'

export interface Family {
  id: FamilyId
  label: string
  color: string // hex accent used for chips
}

export const FAMILIES: Family[] = [
  { id: 'voice', label: 'Voice (SATB)', color: '#9a6b2f' },
  { id: 'sax', label: 'Saxophones', color: '#2550c4' },
  { id: 'brass', label: 'Brass', color: '#b0551c' },
  { id: 'woodwind', label: 'Woodwinds', color: '#6b4fa1' },
  { id: 'strings', label: 'Strings & Fretted', color: '#96711a' },
  { id: 'keys', label: 'Keys & Mallets', color: '#2a7d7d' },
]

export interface Instrument {
  id: string
  name: string
  key: string // 'C', 'B♭', 'E♭', 'F', 'A', 'G', 'D', 'E♭'…
  family: FamilyId
  offset: number // written = concert + offset (mod 12)
  sounds: string // plain-language rule
}

export const INSTRUMENTS: Instrument[] = [
  // ── Voice ──
  { id: 'vox-lead', name: 'Lead Vocal / Melody', key: 'C', family: 'voice', offset: 0, sounds: 'Non-transposing — sings at concert pitch.' },
  { id: 'vox-s', name: 'Soprano', key: 'C', family: 'voice', offset: 0, sounds: 'Non-transposing — reads treble clef at concert pitch.' },
  { id: 'vox-a', name: 'Alto', key: 'C', family: 'voice', offset: 0, sounds: 'Non-transposing — reads treble clef at concert pitch.' },
  { id: 'vox-t', name: 'Tenor', key: 'C', family: 'voice', offset: 0, sounds: 'Same note names, but sounds an octave below the treble staff (8vb).' },
  { id: 'vox-b', name: 'Bass', key: 'C', family: 'voice', offset: 0, sounds: 'Non-transposing — reads bass clef at concert pitch.' },

  // ── Saxophones ──
  { id: 'sax-sop', name: 'Soprano Saxophone', key: 'B♭', family: 'sax', offset: 2, sounds: 'Sounds a major 2nd lower than written.' },
  { id: 'sax-alto', name: 'Alto Saxophone', key: 'E♭', family: 'sax', offset: 9, sounds: 'Sounds a major 6th lower than written.' },
  { id: 'sax-tenor', name: 'Tenor Saxophone', key: 'B♭', family: 'sax', offset: 2, sounds: 'Sounds a major 9th (octave + step) lower than written.' },
  { id: 'sax-bari', name: 'Baritone Saxophone', key: 'E♭', family: 'sax', offset: 9, sounds: 'Sounds an octave + major 6th lower than written.' },
  { id: 'sax-cmel', name: 'C Melody Saxophone', key: 'C', family: 'sax', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },

  // ── Brass ──
  { id: 'tpt-c', name: 'Trumpet in C', key: 'C', family: 'brass', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'tpt-bb', name: 'Trumpet in B♭', key: 'B♭', family: 'brass', offset: 2, sounds: 'Sounds a major 2nd lower than written.' },
  { id: 'tpt-d', name: 'Trumpet in D', key: 'D', family: 'brass', offset: 10, sounds: 'Sounds a major 2nd higher than written.' },
  { id: 'tpt-eb', name: 'Trumpet in E♭', key: 'E♭', family: 'brass', offset: 9, sounds: 'Sounds a minor 3rd higher than written.' },
  { id: 'cornet', name: 'Cornet in B♭', key: 'B♭', family: 'brass', offset: 2, sounds: 'Sounds a major 2nd lower than written.' },
  { id: 'flugel', name: 'Flugelhorn in B♭', key: 'B♭', family: 'brass', offset: 2, sounds: 'Sounds a major 2nd lower than written.' },
  { id: 'horn-f', name: 'French Horn in F', key: 'F', family: 'brass', offset: 7, sounds: 'Sounds a perfect 5th lower than written.' },
  { id: 'alto-horn', name: 'Alto / Tenor Horn in E♭', key: 'E♭', family: 'brass', offset: 9, sounds: 'Sounds a major 6th lower than written.' },
  { id: 'trombone', name: 'Trombone', key: 'C', family: 'brass', offset: 0, sounds: 'Non-transposing — bass clef concert pitch.' },
  { id: 'bass-tbn', name: 'Bass Trombone', key: 'C', family: 'brass', offset: 0, sounds: 'Non-transposing — bass clef concert pitch.' },
  { id: 'euph-tc', name: 'Euphonium / Baritone (treble clef)', key: 'B♭', family: 'brass', offset: 2, sounds: 'Sounds a major 9th lower than written.' },
  { id: 'euph-bc', name: 'Euphonium (bass clef)', key: 'C', family: 'brass', offset: 0, sounds: 'Non-transposing — bass clef concert pitch.' },
  { id: 'tuba', name: 'Tuba', key: 'C', family: 'brass', offset: 0, sounds: 'Non-transposing — reads concert pitch regardless of tuba size.' },

  // ── Woodwinds ──
  { id: 'flute', name: 'Flute', key: 'C', family: 'woodwind', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'piccolo', name: 'Piccolo', key: 'C', family: 'woodwind', offset: 0, sounds: 'Same note names — sounds an octave above written.' },
  { id: 'alto-flute', name: 'Alto Flute in G', key: 'G', family: 'woodwind', offset: 5, sounds: 'Sounds a perfect 4th lower than written.' },
  { id: 'bass-flute', name: 'Bass Flute', key: 'C', family: 'woodwind', offset: 0, sounds: 'Same note names — sounds an octave below written.' },
  { id: 'oboe', name: 'Oboe', key: 'C', family: 'woodwind', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'oboe-amore', name: "Oboe d'amore in A", key: 'A', family: 'woodwind', offset: 3, sounds: 'Sounds a minor 3rd lower than written.' },
  { id: 'eng-horn', name: 'English Horn in F', key: 'F', family: 'woodwind', offset: 7, sounds: 'Sounds a perfect 5th lower than written.' },
  { id: 'clar-bb', name: 'Clarinet in B♭', key: 'B♭', family: 'woodwind', offset: 2, sounds: 'Sounds a major 2nd lower than written.' },
  { id: 'clar-a', name: 'Clarinet in A', key: 'A', family: 'woodwind', offset: 3, sounds: 'Sounds a minor 3rd lower than written.' },
  { id: 'clar-eb', name: 'Clarinet in E♭', key: 'E♭', family: 'woodwind', offset: 9, sounds: 'Sounds a minor 3rd higher than written.' },
  { id: 'bass-clar', name: 'Bass Clarinet in B♭', key: 'B♭', family: 'woodwind', offset: 2, sounds: 'Sounds a major 9th lower than written.' },
  { id: 'alto-clar', name: 'Alto Clarinet in E♭', key: 'E♭', family: 'woodwind', offset: 9, sounds: 'Sounds a major 6th lower than written.' },
  { id: 'bassoon', name: 'Bassoon', key: 'C', family: 'woodwind', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'contra-bsn', name: 'Contrabassoon', key: 'C', family: 'woodwind', offset: 0, sounds: 'Same note names — sounds an octave below written.' },
  { id: 'recorder', name: 'Recorder', key: 'C', family: 'woodwind', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },

  // ── Strings & fretted ──
  { id: 'violin', name: 'Violin', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'viola', name: 'Viola', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — alto clef at concert pitch.' },
  { id: 'cello', name: 'Cello', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — bass clef at concert pitch.' },
  { id: 'bass', name: 'Double Bass', key: 'C', family: 'strings', offset: 0, sounds: 'Same note names — sounds an octave below written.' },
  { id: 'guitar', name: 'Guitar', key: 'C', family: 'strings', offset: 0, sounds: 'Same note names — sounds an octave below written.' },
  { id: 'bass-gtr', name: 'Bass Guitar', key: 'C', family: 'strings', offset: 0, sounds: 'Same note names — sounds an octave below written.' },
  { id: 'ukulele', name: 'Ukulele', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'mandolin', name: 'Mandolin', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'banjo', name: 'Banjo', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },

  // ── Keys & mallets ──
  { id: 'piano', name: 'Piano', key: 'C', family: 'keys', offset: 0, sounds: 'Concert pitch — the reference for everyone else.' },
  { id: 'organ', name: 'Organ', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'harp', name: 'Harp', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'accordion', name: 'Accordion', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'celesta', name: 'Celesta', key: 'C', family: 'keys', offset: 0, sounds: 'Same note names — sounds an octave above written.' },
  { id: 'glock', name: 'Glockenspiel', key: 'C', family: 'keys', offset: 0, sounds: 'Same note names — sounds two octaves above written.' },
  { id: 'xylo', name: 'Xylophone', key: 'C', family: 'keys', offset: 0, sounds: 'Same note names — sounds an octave above written.' },
  { id: 'marimba', name: 'Marimba', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'vibes', name: 'Vibraphone', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'timpani', name: 'Timpani', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — concert pitch.' },
]

// ── Spelling ──────────────────────────────────────────────────────────

const FLAT_NAMES = ['C', 'D♭', 'D', 'E♭', 'E', 'F', 'G♭', 'G', 'A♭', 'A', 'B♭', 'B']

/** Natural letter of each pitch class (flat spelling) — for staff placement. */
export const FLAT_LETTER = ['C', 'D', 'D', 'E', 'E', 'F', 'G', 'G', 'A', 'A', 'B', 'B']
const SHARP_NAMES = ['C', 'C♯', 'D', 'D♯', 'E', 'F', 'F♯', 'G', 'G♯', 'A', 'A♯', 'B']

// Fifths value for each preferred major-key spelling (negative = flats)
// pc:    C  Db  D  Eb  E  F  F#  G  Ab  A  Bb  B
const MAJOR_FIFTHS = [0, -5, 2, -3, 4, -1, 6, 1, -4, 3, -2, 5]
// pc 6 is a tie: F♯ (+6) and G♭ (−6) are equally valid.

export type Spelling = 'flat' | 'sharp'

export function noteName(pc: number, pref: Spelling = 'flat'): string {
  const p = ((pc % 12) + 12) % 12
  return (pref === 'flat' ? FLAT_NAMES : SHARP_NAMES)[p]
}

/** Preferred major-key spelling for a pitch class (fewest accidentals). */
export function keySpelling(pc: number): { name: string; fifths: number; tie?: string } {
  const p = ((pc % 12) + 12) % 12
  if (p === 6) return { name: 'F♯ / G♭', fifths: 6, tie: '6♯ = 6♭' }
  return { name: FLAT_NAMES[p], fifths: MAJOR_FIFTHS[p] }
}

/** Preferred minor-key spelling, indexed by tonic pitch class. */
// pc:      C   C♯   D  E♭  E   F  F♯   G  G♯  A  B♭   B
const MINOR_FIFTHS = [-3, 4, -1, -6, 1, -4, 3, -2, 5, 0, -5, 2]

export function minorKeySpelling(pc: number): { name: string; fifths: number } {
  const p = ((pc % 12) + 12) % 12
  const fifths = MINOR_FIFTHS[p]
  const name = fifths > 0 ? SHARP_NAMES[p] : FLAT_NAMES[p]
  return { name, fifths }
}

export function fifthsLabel(fifths: number): string {
  if (fifths === 0) return 'no sharps or flats'
  const n = Math.abs(fifths)
  return `${n} ${fifths > 0 ? (n === 1 ? 'sharp' : 'sharps') : n === 1 ? 'flat' : 'flats'}`
}

const INTERVALS: Record<number, string> = {
  0: 'perfect unison', 1: 'minor 2nd', 2: 'major 2nd', 3: 'minor 3rd',
  4: 'major 3rd', 5: 'perfect 4th', 6: 'tritone', 7: 'perfect 5th',
  8: 'minor 6th', 9: 'major 6th', 10: 'minor 7th', 11: 'major 7th',
}

/** How far the written part sits from concert pitch for this instrument. */
export function writtenIntervalLabel(inst: Instrument): string {
  const o = ((inst.offset % 12) + 12) % 12
  if (o === 0) return 'Written part = concert pitch'
  if (o <= 6) return `Written part = a ${INTERVALS[o]} above concert`
  return `Written part = a ${INTERVALS[12 - o]} below concert`
}

/** Transpose a pitch class for an instrument. */
export function transpose(pc: number, inst: Instrument, toWritten: boolean): number {
  const o = toWritten ? inst.offset : -inst.offset
  return (((pc + o) % 12) + 12) % 12
}

/** Transpose a pitch class from one instrument's written pitch to another's. */
export function transposeBetween(pc: number, from: Instrument, to: Instrument): number {
  return (((pc - from.offset + to.offset) % 12) + 12) % 12
}

// ── Chords ────────────────────────────────────────────────────────────

export interface ChordQuality {
  id: string
  suffix: string // '' for major
  label: string
  intervals: number[] // semitones from root
}

export const CHORDS: ChordQuality[] = [
  { id: 'power5', suffix: '5', label: 'Power chord (5)', intervals: [0, 7] },
  { id: 'maj', suffix: '', label: 'Major', intervals: [0, 4, 7] },
  { id: 'min', suffix: 'm', label: 'Minor', intervals: [0, 3, 7] },
  { id: 'dom7', suffix: '7', label: 'Dominant 7', intervals: [0, 4, 7, 10] },
  { id: 'maj7', suffix: 'maj7', label: 'Major 7', intervals: [0, 4, 7, 11] },
  { id: 'min7', suffix: 'm7', label: 'Minor 7', intervals: [0, 3, 7, 10] },
  { id: 'min7b5', suffix: 'm7♭5', label: 'Half-diminished', intervals: [0, 3, 6, 10] },
  { id: 'dim7', suffix: '°7', label: 'Diminished 7', intervals: [0, 3, 6, 9] },
  { id: 'aug', suffix: 'aug', label: 'Augmented', intervals: [0, 4, 8] },
  { id: 'sus4', suffix: 'sus4', label: 'Sus 4', intervals: [0, 5, 7] },
  { id: 'sus2', suffix: 'sus2', label: 'Sus 2', intervals: [0, 2, 7] },
  { id: 'add9', suffix: 'add9', label: 'Add 9', intervals: [0, 4, 7, 14] },
  { id: 'six', suffix: '6', label: 'Sixth', intervals: [0, 4, 7, 9] },
  { id: 'nine', suffix: '9', label: 'Ninth', intervals: [0, 4, 7, 10, 14] },
  { id: 'min9', suffix: 'm9', label: 'Minor 9', intervals: [0, 3, 7, 10, 14] },
  { id: 'thirteen', suffix: '13', label: 'Thirteenth', intervals: [0, 4, 7, 10, 14, 17, 21] },
  { id: 'sevenflat9', suffix: '7♭9', label: '7 flat 9', intervals: [0, 4, 7, 10, 13] },
]

/** Spell a chord's notes for a given instrument's written part. */
export function chordNotes(rootPc: number, chord: ChordQuality, inst: Instrument): number[] {
  return chord.intervals.map((i) => transpose((rootPc + i) % 12, inst, true))
}

// ── Chord spelling (real note names, not just pitch classes) ─────────

const LETTERS = ['C', 'D', 'E', 'F', 'G', 'A', 'B']
const LETTER_PC: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }

/** Diatonic letter-steps each chord interval sits above the root. */
export const INTERVAL_STEPS: Record<number, number> = {
  0: 0, 1: 1, 2: 1, 3: 2, 4: 2, 5: 3, 6: 4, 7: 4, 8: 4, 9: 5, 10: 6,
  11: 6, 12: 0, 13: 1, 14: 1, 15: 2, 16: 2, 17: 3, 18: 4, 19: 4, 20: 5, 21: 5,
}

/** Root name for a pitch class; the F♯/G♭ tie follows the user's spelling toggle. */
export function rootNameFor(pc: number, spelling: Spelling = 'flat'): string {
  const p = ((pc % 12) + 12) % 12
  if (p === 6) return spelling === 'sharp' ? 'F♯' : 'G♭'
  return FLAT_NAMES[p]
}

/** Full chord symbol, e.g. "C9", "F♯m7", "B♭maj7". */
export function chordName(rootPc: number, chord: ChordQuality, spelling: Spelling = 'flat'): string {
  return rootNameFor(rootPc, spelling) + chord.suffix
}

/**
 * Spell every tone of a chord with correct note letters, e.g.
 * C dominant 9 → ["C", "E", "G", "B♭", "D"].
 */
export function spellChordTones(rootPc: number, chord: ChordQuality, spelling: Spelling = 'flat'): string[] {
  const root = rootNameFor(rootPc, spelling)
  const rootLetterIdx = LETTERS.indexOf(root[0])
  return chord.intervals.map((semi) => {
    const steps = INTERVAL_STEPS[semi] ?? 0
    const letterIdx = (rootLetterIdx + steps) % 7
    const naturalPc = LETTER_PC[LETTERS[letterIdx]]
    let acc = (((rootPc + semi) % 12) - naturalPc) % 12
    if (acc > 6) acc -= 12
    if (acc < -6) acc += 12
    const accStr = acc === 0 ? '' : acc > 0 ? '♯'.repeat(acc) : '♭'.repeat(-acc)
    return LETTERS[letterIdx] + accStr
  })
}

/** Spell a chord's notes mapped from one instrument's written chord to another's. */
export function chordNotesBetween(rootPc: number, chord: ChordQuality, from: Instrument, to: Instrument): number[] {
  return chord.intervals.map((i) => transposeBetween((rootPc + i) % 12, from, to))
}

export function familyOf(inst: Instrument): Family {
  return FAMILIES.find((f) => f.id === inst.family)!
}

```

## 7a. File 2a — `src/components/StaffChord.tsx` (band-on-staff renderer)

The treble clef is a TRUE clef — the actual glyph outline extracted from the Noto Music font (U+1D11E), normalized so the G line sits at svg y=0. Do not redraw it by hand.

```tsx
import { FLAT_LETTER, INTERVAL_STEPS } from '@/lib/music'

/** True treble clef outline (from the Noto Music font), normalized: the G line
 *  (2nd staff line from the bottom) passes through svg y = 0. */
const CLEF_D =
  'M31.4 -55.1Q30 -60.4 29.1 -65.6Q28.2 -70.8 28.2 -76.2Q28.2 -80.9 28.9 -85.1Q29.5 -89.2 30.7 -92.7Q32 -96.7 34.1 -100.2Q36.2 -103.8 38.6 -106.1Q40.9 -108.4 42.7 -108.4Q45.1 -108.4 49.3 -99.9Q51.4 -95.6 52.4 -90.6Q53.4 -85.6 53.4 -79.9Q53.4 -72.8 51.5 -65.8Q49.6 -58.7 46 -52.5Q42.3 -46.3 37.2 -41.6L40.7 -24.8Q42.2 -25 43.2 -25.1Q44.2 -25.2 44.7 -25.2Q50.8 -25.2 55.6 -21.8Q60.4 -18.3 63.3 -12.7Q66.1 -7.1 66.1 -0.4Q66.1 7.3 62.2 13.5Q58.2 19.6 50.3 22.5Q50.8 24.2 53.2 36.7Q53.8 39.7 54.1 41.5Q54.4 43.2 54.5 44.5Q54.6 45.8 54.6 47.5Q54.6 52.5 52.2 56.5Q49.7 60.4 45.6 62.6Q41.4 64.8 36.3 64.8Q31.1 64.8 27.1 62.9Q23.1 60.9 20.8 57.5Q18.5 54 18.5 49.5Q18.5 44.7 21.1 41.5Q23.8 38.3 28.7 38.3Q32.9 38.3 35.5 41.4Q38.2 44.4 38.2 48.6Q38.2 52.2 35.7 54.9Q33.2 57.6 29.2 57.6H28.2Q30.8 61.5 36.4 61.5Q43.3 61.5 47.2 57Q51.1 52.5 51.1 45.5Q51.1 43.8 50.7 41Q50.3 38.1 49.3 34.1Q48.3 30.1 47.8 27.5Q47.2 24.9 47 23.8Q43.6 24.8 39 24.8Q30.4 24.8 22.2 19.8Q14.2 14.8 9.6 6.6Q5 -1.6 5 -11.1Q5 -20.1 9.1 -28Q13.2 -35.9 19.2 -42.5Q25.3 -49.1 31.4 -55.1ZM34.1 -57.6Q36.4 -58.8 39 -62.1Q41.6 -65.3 44 -69.5Q46.4 -73.7 47.9 -78Q49.4 -82.2 49.4 -85.6Q49.4 -89.2 48.3 -91.3Q47.2 -93.4 44.5 -93.4Q42.1 -93.4 39.9 -91.2Q37.6 -89 35.9 -85.3Q34.1 -81.7 33.1 -77.2Q32.1 -72.7 32.1 -68Q32.1 -64.8 32.8 -62.2Q33.4 -59.6 34.1 -57.6ZM39.8 -12.9Q37.1 -12.3 34.7 -10.4Q32.3 -8.4 30.9 -5.7Q29.4 -2.9 29.4 0.2Q29.4 2.7 30.7 5.3Q32 8 33.9 9.6Q35.2 10.8 36.5 11.4Q38 12.1 38 12.7Q38 13 37 13.3Q33.2 12.4 30.2 9.9Q27.1 7.4 25.4 3.8Q23.6 0.3 23.6 -3.7Q23.6 -8 25.4 -12Q27.1 -16 30.2 -19.2Q33.4 -22.4 37.4 -24L34.5 -39.1Q22.9 -29.7 17.5 -20.7Q12 -11.6 12 -2.7Q12 3.8 15.4 9.4Q18.8 15 24.7 18.4Q30.6 21.9 38 21.9Q40 21.9 42 21.5Q44.1 21.1 46.4 20.5ZM49.5 19.5Q59.3 15.3 59.3 2.3Q59.3 -2 57.1 -5.6Q54.9 -9.1 51.2 -11.2Q47.5 -13.3 42.9 -13.3Z'

export interface StaffTone {
  semitones: number // interval above root
  color: string // owner player's color (or neutral)
  label: string // legend label, e.g. "Tenor Saxophone"
}

const LETTER_PC: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }
const LETTERS = ['C', 'D', 'E', 'F', 'G', 'A', 'B']

interface Placed {
  pos: number // absolute diatonic position (C4 = 28)
  acc: string // '', '♭', '♯', '♭♭'…
  color: string
  label: string
}

/**
 * Draws the band's chord on a treble-clef staff. Each notehead takes the color
 * of the player who owns that tone; chord players get the bracket in the legend.
 */
export function StaffChord({
  rootPc,
  intervals,
  tones,
  bracketColor,
  bracketLabel,
  t,
}: {
  rootPc: number
  intervals: number[]
  tones: StaffTone[]
  bracketColor?: string
  bracketLabel?: string
  t: { staffTitle: string; playsWholeChord: string; concertNote: string }
}) {
  const rootLetter = LETTERS.indexOf(FLAT_LETTER[((rootPc % 12) + 12) % 12])
  const rootOctave = rootLetter >= 4 ? 3 : 4 // keep tall chords on the staff
  const rootAbs = rootOctave * 7 + rootLetter

  const placed: Placed[] = intervals.map((s, i) => {
    const pos = rootAbs + Math.floor(s / 12) * 7 + INTERVAL_STEPS[s % 12]
    const naturalPc = LETTER_PC[LETTERS[pos % 7]]
    let diff = (((rootPc + s) % 12) - naturalPc) % 12
    if (diff > 6) diff -= 12
    if (diff < -6) diff += 12
    const acc = diff === 0 ? '' : diff > 0 ? '♯'.repeat(diff) : '♭'.repeat(-diff)
    const tone = tones[i]
    return { pos, acc, color: tone?.color ?? 'hsl(var(--foreground))', label: tone?.label ?? '' }
  })

  // ── Geometry ──
  const STEP = 5 // px per diatonic step
  const BOTTOM = 30 // diatonic pos of the bottom staff line (E4)
  const minPos = Math.min(...placed.map((p) => p.pos))
  const maxPos = Math.max(...placed.map((p) => p.pos))
  const topPad = Math.max(0, maxPos - (BOTTOM + 8)) * STEP + 14
  const botPad = Math.max(0, BOTTOM - 2 - minPos) * STEP + 14
  const staffH = 8 * STEP
  const H = topPad + staffH + botPad
  const yOf = (pos: number) => topPad + staffH - (pos - BOTTOM) * STEP

  const X_LINES = 66
  const X_NOTE = 150
  const W = 340

  // seconds (pos diff 1) get left/right notehead offsets
  const sorted = [...placed].sort((a, b) => a.pos - b.pos)
  const xOf = new Map<Placed, number>()
  sorted.forEach((p, i) => {
    const prev = sorted[i - 1]
    xOf.set(p, prev && p.pos - prev.pos === 1 && xOf.get(prev) === X_NOTE ? X_NOTE + 11 : X_NOTE)
  })

  // ledger lines needed
  const ledgers: { y: number; x: number }[] = []
  for (const p of placed) {
    const x = xOf.get(p)!
    if (p.pos <= BOTTOM - 2) {
      for (let lp = BOTTOM - 2; lp >= p.pos; lp -= 2) ledgers.push({ y: yOf(lp), x })
    }
    if (p.pos >= BOTTOM + 10) {
      for (let lp = BOTTOM + 10; lp <= p.pos; lp += 2) ledgers.push({ y: yOf(lp), x })
    }
  }

  // legend entries (unique colors in chord order)
  const seen = new Set<string>()
  const legend = placed
    .filter((p) => p.label)
    .filter((p) => (seen.has(p.label) ? false : (seen.add(p.label), true)))

  return (
    <div>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="w-full"
        role="img"
        aria-label={`${t.staffTitle}: ${t.concertNote}`}
      >
        {/* staff lines */}
        {[0, 2, 4, 6, 8].map((s) => (
          <line
            key={s}
            x1={X_LINES - 34}
            x2={W - 14}
            y1={yOf(BOTTOM + s)}
            y2={yOf(BOTTOM + s)}
            stroke="hsl(var(--foreground))"
            strokeWidth="1"
            opacity="0.75"
          />
        ))}
        {/* treble clef — G line (pos BOTTOM+2) through the spiral */}
        <g transform={`translate(8, ${yOf(BOTTOM + 2)}) scale(${(staffH * 1.72) / 173.2})`}>
          <path d={CLEF_D} fill="hsl(var(--foreground))" />
        </g>
        {/* ledger lines */}
        {ledgers.map((l, i) => (
          <line
            key={i}
            x1={l.x - 11}
            x2={l.x + 11}
            y1={l.y}
            y2={l.y}
            stroke="hsl(var(--foreground))"
            strokeWidth="1"
            opacity="0.75"
          />
        ))}
        {/* noteheads + accidentals */}
        {placed.map((p, i) => {
          const x = xOf.get(p)!
          const y = yOf(p.pos)
          return (
            <g key={i}>
              {p.acc && (
                <text
                  x={x - 16}
                  y={y + 5}
                  fontSize="15"
                  fontWeight="700"
                  fill="hsl(var(--foreground))"
                  className="note-display"
                >
                  {p.acc}
                </text>
              )}
              <ellipse
                cx={x}
                cy={y}
                rx="6.2"
                ry="4.4"
                transform={`rotate(-18 ${x} ${y})`}
                fill={p.color}
                stroke="hsl(var(--foreground))"
                strokeWidth="0.75"
              />
            </g>
          )
        })}
        {/* whole-chord bracket for keys/guitar players */}
        {bracketColor && (
          <path
            d={`M ${W - 40} ${yOf(maxPos) - 10} q 8 0 8 8 l 0 ${Math.max(10, yOf(minPos) - yOf(maxPos) + 4)} q 0 8 -8 8`}
            fill="none"
            stroke={bracketColor}
            strokeWidth="3"
            strokeLinecap="round"
          />
        )}
      </svg>

      {/* legend — who plays what */}
      <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1.5">
        {bracketColor && bracketLabel && (
          <li className="flex items-center gap-1.5 text-xs text-foreground/80">
            <span className="inline-block h-2.5 w-2.5 rounded-full border-2" style={{ borderColor: bracketColor }} aria-hidden />
            <span className="font-semibold">{bracketLabel}</span>
            <span className="text-muted-foreground">· {t.playsWholeChord}</span>
          </li>
        )}
        {legend.map((p) => (
          <li key={p.label} className="flex items-center gap-1.5 text-xs text-foreground/80">
            <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: p.color }} aria-hidden />
            <span className="font-semibold">{p.label}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

```

## 7. File 2 — key UI pieces (React + Tailwind) (React + Tailwind)

### 7.1 Page state & derived values (the heart of `Home.tsx`)

```tsx
type Mode = 'major' | 'minor' | 'chord' | 'note'
interface Player { uid: number; instrumentId: string }

// Section 01 — the sentence (piano ↔ tenor sax by default, both swappable)
const [fromId, setFromId] = useState('concert')      // 'concert' = the piano
const [toId, setToId] = useState('sax-tenor')
const [pc, setPc] = useState(9)                      // A
const [mode, setMode] = useState<Mode>('major')
const [chordId, setChordId] = useState('nine')

// Section 02 — the band (no limit on players)
const [players, setPlayers] = useState<Player[]>([
  { uid: 1, instrumentId: 'tpt-bb' },
  { uid: 2, instrumentId: 'sax-alto' },
  { uid: 3, instrumentId: 'sax-tenor' },
])
const [source, setSource] = useState('concert')      // whose written part is the reference
const [bandPc, setBandPc] = useState(0)              // C
const [qualityId, setQualityId] = useState('nine')   // or 'key-major' / 'key-minor'
const [tones, setTones] = useState<Record<number, number>>({}) // uid → chord-tone pc

// Derived: written→concert→written
const fromInst = fromId === 'concert' ? undefined : instById(fromId)
const toInst = toId === 'concert' ? undefined : instById(toId)
const concertPc = fromInst ? transpose(pc, fromInst, false) : pc
const outPc = toInst ? transpose(concertPc, toInst, true) : concertPc

// Band: concert root from the chosen source, then each player's part
const sourceInst = /* instrument of the player selected as source, or undefined = piano */
const bandConcert = sourceInst ? transpose(bandPc, sourceInst, false) : bandPc

// Who plays chords vs single notes:
const isChordPlayer = (inst: Instrument) => inst.family === 'keys' || inst.family === 'strings'
// Horn/voice default chord tones:
function defaultToneFor(inst: Instrument): number {
  if (inst.id === 'vox-lead' || inst.id === 'vox-s') return 0          // root
  if (inst.id === 'vox-a' || inst.id === 'sax-alto' || inst.id === 'tpt-bb') return 4  // 3rd
  if (inst.id === 'sax-tenor') return 7                                 // 5th
  if (inst.id === 'sax-bari' || inst.id === 'vox-b' || inst.id === 'bass-gtr') return 10 // ♭7
  return 4
}
// A horn's written note for its assigned tone:
const noteOut = transpose((bandConcert + tone) % 12, inst, true)
// A chord player's written chord root:
const chordOut = transpose(bandConcert, inst, true)
```

### 7.2 The sentence UI (structure — keep this exact flow)

```tsx
<div className="flex flex-wrap items-center gap-x-3 gap-y-2">
  <span className="font-serif text-xl">If the</span>
  <InlineInstrumentSelect value={fromId} onChange={setFromId} />   {/* blue, chevron, "( tap to change )" */}
  <span>{fromInst?.family === 'voice' ? 'is singing' : 'is playing'}</span>
</div>
<Segmented options={[Major key, Minor key, Chord, Note]} value={mode} onChange={setMode} />
{mode === 'chord' && <>a <ChordSelect value={chordId} onChange={setChordId} /> on</>}
<NoteGrid value={pc} onChange={setPc} spelling={spelling} />       {/* 12 tappable notes */}
<div>the <InlineInstrumentSelect value={toId} onChange={setToId} /> {toInst?.family === 'voice' ? 'sings' : 'plays'}</div>
<ResultText pc={outPc} mode={mode} chordId={chordId} spelling={spelling} big />
```

### 7.3 Answer display (chord mode shows spelled tones)

```tsx
function ResultText({ pc, mode, chordId, spelling, big }) {
  if (mode === 'chord') {
    const c = chordById(chordId)
    return (<>
      <p className="note-display text-6xl font-extrabold">{chordName(pc, c, spelling)}</p>
      <p className="note-display mt-2">{spellChordTones(pc, c, spelling).join(' · ')}</p>
    </>)
  }
  if (mode === 'note') return <p className="text-6xl font-extrabold">{noteName(pc, spelling)}</p>
  const k = mode === 'major' ? keySpelling(pc) : minorKeySpelling(pc)
  return (<>
    <p className="text-6xl font-extrabold">{k.name}</p>
    <p className="mt-2">{mode} key · {fifthsLabel(k.fifths)}</p>
  </>)
}
```

### 7.4 Band row (horn = one note + "Plays the…" selector; keys/strings = full chord)

```tsx
{players.map((p) => {
  const inst = instById(p.instrumentId)
  const chordPlayer = isChordPlayer(inst)
  const tone = toneFor(p.uid, inst)              // assigned tone or smart default
  const noteOut = transpose((bandConcert + tone) % 12, inst, true)
  return (
    <div key={p.uid}>
      <FamilyDot color={familyOf(inst).color} /> {playerLabel(p)} {inst.key !== 'C' && <KeyBadge>{inst.key}</KeyBadge>}
      {chordPlayer || bandMode !== 'chord'
        ? <ResultText pc={transpose(bandConcert, inst, true)} ... />
        : <>{noteName(noteOut, spelling)} <select>…Plays the {root|3rd|5th|♭7…}…</select></>}
    </div>
  )
})}
```

### 7.5 Interaction & polish details that mattered to the user
- Every `<select>`: `appearance-none` + SVG chevron background + blue tint (`bg-secondary`) + **"( tap to change )"** caption beneath; the two sentence pickers get a soft pulsing glow.
- Answer re-mounts on change with `key={...}` + a 0.5s blur-pop CSS animation.
- Scroll reveals: IntersectionObserver, `translate-y-4 opacity-0 blur-[8px]` → visible, 700ms, `prefers-reduced-motion` respected.
- Design: warm ivory `#f6f2e8`, deep royal blue `#03339B`, gold accents; Fraunces serif / Work Sans / JetBrains Mono; grain overlay; floating golden notes + Ken Burns hero wash.

## 8. In-app tour video recipe (SCN standard — reuse for every demo)

1. Serve the built app; drive it with Playwright at 390×720 (deviceScaleFactor 2) with `record_video_dir`.
2. Inject an overlay: **finger dot** (30px circle, royal-blue ring, cubic-bezier movement, press scale) + **caption pill** (bottom-center blue pill narrating each step: "1. Tap a blue box ▾", "2. Tap a key", "The answer updates instantly").
3. Script the real flow (change instrument → tap key → pick 13th chord → scroll to band → add player → change horn's chord tone), ~0.5–1.2s dwell per action.
4. Close the browser **context** to finalize the .webm.
5. Convert (MUST be baseline or phones show a blank box):
   `ffmpeg -y -i in.webm -c:v libx264 -profile:v baseline -level 3.1 -pix_fmt yuv420p -movflags +faststart -crf 28 out.mp4` (trim lead-in with `-ss 1.3` if needed; ~0.2 MB, ~23s).
6. Embed at the **top of the page** above the headline: blue banner "New here? Watch the quick tour", `<video autoplay muted loop playsinline controls preload="auto" src="./demo.mp4">`.

## 9. Verified acceptance tests (must all pass after porting)

| # | Given | Expect |
|---|-------|--------|
| 1 | Piano (C inst) plays A major | Tenor sax plays **B major · 5 sharps** |
| 2 | Piano plays C major | Alto sax plays **A major · 3 sharps** |
| 3 | Piano plays B♭ major | French horn plays **F major** |
| 4 | Piano plays A minor | Alto sax plays **F♯ minor · 3 sharps** |
| 5 | Trumpet's written C9 | Concert is **B♭9**; alto plays **G9 (G·B·D·F·A)** |
| 6 | Band, piano source, C9 | Piano C9 · Trumpet D9 · Alto A9 · Tenor D9 |
| 7 | Band, source = alto's written C (9 chord) | Concert E♭9; trumpet & tenor play F9 |
| 8 | Horn in C9, assigned 3rd, flat spelling | Trumpet shows **G♭**… (single note, never a chord) |
| 9 | Duplicates | Two Lead Vocals labeled **#1 / #2** |
| 10 | Unlimited players | 11+ players render and compute correctly |

- **Copyright mark (required on every page):** `© 2026 SCN Technologies. All rights reserved.` under the "Built by SCN Technologies — accessible by design." footer mark.

## 10. Integration notes for the NTCCA app

- **Zero dependencies** beyond React + Tailwind; `music.ts` is pure TypeScript — also reusable server-side or in a future chord-chart feature.
- All computation is on-device; the feature **works offline** (fits the SCN PWA standard).
- Route suggestion: `/transpose` with a nav entry "Transposer"; keep `familyOf(inst).color` dots for the NTCCA theme if colors differ — but **never encode meaning in color alone** (SCN accessibility standard: add shapes/labels).
- i18n: wrap UI strings (the standalone app already has an English/Spanish string table — ask for `a11y.ts` from the transpose conversation if NTCCA wants bilingual day one).
- PWA/deploy: static build, `base: './'`, works on Vercel as a subdirectory route; no server needed.
