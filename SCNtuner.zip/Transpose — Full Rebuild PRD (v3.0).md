# PRD — "Transpose" (SCN Technologies) — Complete Rebuild Document

**Version:** 3.0 · **Date:** 2026-10-18 · **Owner:** SCN Technologies
**Purpose:** rebuild the app EXACTLY as it stands today if this conversation is ever lost. Every source file below is verbatim — drop them into the matching paths and `npm run build`.

---

## 1. What it is

**Transpose** answers one church question — *"If the piano is playing in A, what does my tenor sax play?"* — for **every instrument and every voice at once**. It's a two-page PWA:

- **`/` (Landing)** — Ken Burns ivory/royal-blue hero, floating gold notes, full-song demo video (67.6 s, "Every Voice, One Answer", sound autoplays), **Get started** → `/app`.
- **`/app` (Tool)** — ONE unified band flow. No disconnected sections.

**The contract that must never break:** *The piano is a C instrument — its key is the key of the music.* Everything transposes from there.

## 2. How the app works (current behavior)

1. **01 Set the key** — sentence-style: "If the [Piano ▾] is playing [Major key / Minor key / Chord / Note]" + 12-key grid (♭/♯ spelling toggle). The source is the leader (piano by default, tappable to anyone). A royal-blue banner states the source.
2. **02 The band plays** — tenor sax is band member #1 (tappable to anybody); "+ Add player" grows the band **without limit** (duplicates auto-numbered). Each player gets a color **first-come-first-serve by join order** + a distinct shape (circle/square/triangle/diamond/outline) for colorblind safety. Horns/voices take ONE chord tone via a "Plays the…" selector (root/3rd/5th/etc.); keys & strings take the whole chord.
3. **The band on the staff** — a real treble staff under the band: the whole concert-pitch chord voicing, noteheads colored by owner, accidentals (♭/♯) spelled correctly, ledger lines, a royal-blue bracket for chord players, and a color legend. **The treble clef is the TRUE Noto Music glyph outline (U+1D11E), not hand-drawn.**
4. **PWA** — installable, fully offline (service worker `transpose-v3`, self-hosted fonts, manifest `#03339b`).
5. **SCN signature accessibility** — colorblind (shapes + 3px outlines), calm mode, large text, dark mode, English/Español, persisted in `localStorage('transpose-a11y')`.
6. **Autoplay music** — video attempts sound-on autoplay; if the browser blocks it (first-ever visit), it plays muted and flips sound on at the first touch/scroll/key. No mute button, no controls bar. **"© 2026 SCN Technologies. All rights reserved."** under the "Built by SCN Technologies — accessible by design." footer on BOTH pages, plus "♪ Every Voice, One Answer — SCN Technologies" under the video.

## 3. Stack & layout

React 18 + TypeScript + Vite + Tailwind + shadcn/ui. `vite.config.ts` must set `base: './'`. React Router: `/` → Landing, `/app` → Home, `*` → redirect `/`. Deploy: Vercel static, SPA rewrites in `vercel.json`. Fonts self-hosted woff2 in `public/fonts/` (Fraunces, Work Sans, JetBrains Mono).

**File tree:**
```
index.html  vite.config.ts  tailwind.config  tsconfig…
vercel.json
public/manifest.webmanifest  public/sw.js  public/demo.mp4  public/icons/  public/fonts/
src/main.tsx  src/App.tsx  src/index.css  src/fonts.css
src/lib/music.ts  src/lib/a11y.ts  src/lib/utils.ts (shadcn cn)
src/pages/Landing.tsx  src/pages/Home.tsx
src/components/Reveal.tsx  src/components/A11yPanel.tsx  src/components/StaffChord.tsx
```

## 4. Transposition math (the contract)

Pitch classes C=0…B=11. `written = (concert + offset) mod 12`. Offsets: B♭ +2, E♭ +9, F +7, A +3, G +5, D +10, C 0. Keys spelled via major/minor circle-of-fifths tables (F♯/G♭ is a labeled tie). Chords spelled diatonically (INTERVAL_STEPS letter-step table), power chords through 13ths, ♯/♭ from the root's letter. ~56 instruments in 6 families: voice, sax, brass, woodwind, strings (fretted + orchestral strings), keys/mallets. Voices are C instruments; guitar/bass/piccolo/tenor voice share concert names with an octave shift only.

---
## 5. Source files — VERBATIM


### `src/lib/music.ts`

```ts
// ── Transposition engine ──────────────────────────────────────────────
// Convention: written pitch class = (concert pitch class + offset) mod 12.
// Pitch classes: C=0, C#/Db=1, D=2, D#/Eb=3, E=4, F=5,
// F#/Gb=6, G=7, G#/Ab=8, A=9, A#/Bb=10, B=11

export type FamilyId =
  | 'voice'
  | 'sax'
  | 'brass'
  | 'woodwind'
  | 'strings'
  | 'keys'

export interface Family {
  id: FamilyId
  label: string
  color: string // hex accent used for chips
}

export const FAMILIES: Family[] = [
  { id: 'voice', label: 'Voice (SATB)', color: '#9a6b2f' },
  { id: 'sax', label: 'Saxophones', color: '#2550c4' },
  { id: 'brass', label: 'Brass', color: '#b0551c' },
  { id: 'woodwind', label: 'Woodwinds', color: '#6b4fa1' },
  { id: 'strings', label: 'Strings & Fretted', color: '#96711a' },
  { id: 'keys', label: 'Keys & Mallets', color: '#2a7d7d' },
]

export interface Instrument {
  id: string
  name: string
  key: string // 'C', 'B♭', 'E♭', 'F', 'A', 'G', 'D', 'E♭'…
  family: FamilyId
  offset: number // written = concert + offset (mod 12)
  sounds: string // plain-language rule
}

export const INSTRUMENTS: Instrument[] = [
  // ── Voice ──
  { id: 'vox-lead', name: 'Lead Vocal / Melody', key: 'C', family: 'voice', offset: 0, sounds: 'Non-transposing — sings at concert pitch.' },
  { id: 'vox-s', name: 'Soprano', key: 'C', family: 'voice', offset: 0, sounds: 'Non-transposing — reads treble clef at concert pitch.' },
  { id: 'vox-a', name: 'Alto', key: 'C', family: 'voice', offset: 0, sounds: 'Non-transposing — reads treble clef at concert pitch.' },
  { id: 'vox-t', name: 'Tenor', key: 'C', family: 'voice', offset: 0, sounds: 'Same note names, but sounds an octave below the treble staff (8vb).' },
  { id: 'vox-b', name: 'Bass', key: 'C', family: 'voice', offset: 0, sounds: 'Non-transposing — reads bass clef at concert pitch.' },

  // ── Saxophones ──
  { id: 'sax-sop', name: 'Soprano Saxophone', key: 'B♭', family: 'sax', offset: 2, sounds: 'Sounds a major 2nd lower than written.' },
  { id: 'sax-alto', name: 'Alto Saxophone', key: 'E♭', family: 'sax', offset: 9, sounds: 'Sounds a major 6th lower than written.' },
  { id: 'sax-tenor', name: 'Tenor Saxophone', key: 'B♭', family: 'sax', offset: 2, sounds: 'Sounds a major 9th (octave + step) lower than written.' },
  { id: 'sax-bari', name: 'Baritone Saxophone', key: 'E♭', family: 'sax', offset: 9, sounds: 'Sounds an octave + major 6th lower than written.' },
  { id: 'sax-cmel', name: 'C Melody Saxophone', key: 'C', family: 'sax', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },

  // ── Brass ──
  { id: 'tpt-c', name: 'Trumpet in C', key: 'C', family: 'brass', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'tpt-bb', name: 'Trumpet in B♭', key: 'B♭', family: 'brass', offset: 2, sounds: 'Sounds a major 2nd lower than written.' },
  { id: 'tpt-d', name: 'Trumpet in D', key: 'D', family: 'brass', offset: 10, sounds: 'Sounds a major 2nd higher than written.' },
  { id: 'tpt-eb', name: 'Trumpet in E♭', key: 'E♭', family: 'brass', offset: 9, sounds: 'Sounds a minor 3rd higher than written.' },
  { id: 'cornet', name: 'Cornet in B♭', key: 'B♭', family: 'brass', offset: 2, sounds: 'Sounds a major 2nd lower than written.' },
  { id: 'flugel', name: 'Flugelhorn in B♭', key: 'B♭', family: 'brass', offset: 2, sounds: 'Sounds a major 2nd lower than written.' },
  { id: 'horn-f', name: 'French Horn in F', key: 'F', family: 'brass', offset: 7, sounds: 'Sounds a perfect 5th lower than written.' },
  { id: 'alto-horn', name: 'Alto / Tenor Horn in E♭', key: 'E♭', family: 'brass', offset: 9, sounds: 'Sounds a major 6th lower than written.' },
  { id: 'trombone', name: 'Trombone', key: 'C', family: 'brass', offset: 0, sounds: 'Non-transposing — bass clef concert pitch.' },
  { id: 'bass-tbn', name: 'Bass Trombone', key: 'C', family: 'brass', offset: 0, sounds: 'Non-transposing — bass clef concert pitch.' },
  { id: 'euph-tc', name: 'Euphonium / Baritone (treble clef)', key: 'B♭', family: 'brass', offset: 2, sounds: 'Sounds a major 9th lower than written.' },
  { id: 'euph-bc', name: 'Euphonium (bass clef)', key: 'C', family: 'brass', offset: 0, sounds: 'Non-transposing — bass clef concert pitch.' },
  { id: 'tuba', name: 'Tuba', key: 'C', family: 'brass', offset: 0, sounds: 'Non-transposing — reads concert pitch regardless of tuba size.' },

  // ── Woodwinds ──
  { id: 'flute', name: 'Flute', key: 'C', family: 'woodwind', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'piccolo', name: 'Piccolo', key: 'C', family: 'woodwind', offset: 0, sounds: 'Same note names — sounds an octave above written.' },
  { id: 'alto-flute', name: 'Alto Flute in G', key: 'G', family: 'woodwind', offset: 5, sounds: 'Sounds a perfect 4th lower than written.' },
  { id: 'bass-flute', name: 'Bass Flute', key: 'C', family: 'woodwind', offset: 0, sounds: 'Same note names — sounds an octave below written.' },
  { id: 'oboe', name: 'Oboe', key: 'C', family: 'woodwind', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'oboe-amore', name: "Oboe d'amore in A", key: 'A', family: 'woodwind', offset: 3, sounds: 'Sounds a minor 3rd lower than written.' },
  { id: 'eng-horn', name: 'English Horn in F', key: 'F', family: 'woodwind', offset: 7, sounds: 'Sounds a perfect 5th lower than written.' },
  { id: 'clar-bb', name: 'Clarinet in B♭', key: 'B♭', family: 'woodwind', offset: 2, sounds: 'Sounds a major 2nd lower than written.' },
  { id: 'clar-a', name: 'Clarinet in A', key: 'A', family: 'woodwind', offset: 3, sounds: 'Sounds a minor 3rd lower than written.' },
  { id: 'clar-eb', name: 'Clarinet in E♭', key: 'E♭', family: 'woodwind', offset: 9, sounds: 'Sounds a minor 3rd higher than written.' },
  { id: 'bass-clar', name: 'Bass Clarinet in B♭', key: 'B♭', family: 'woodwind', offset: 2, sounds: 'Sounds a major 9th lower than written.' },
  { id: 'alto-clar', name: 'Alto Clarinet in E♭', key: 'E♭', family: 'woodwind', offset: 9, sounds: 'Sounds a major 6th lower than written.' },
  { id: 'bassoon', name: 'Bassoon', key: 'C', family: 'woodwind', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'contra-bsn', name: 'Contrabassoon', key: 'C', family: 'woodwind', offset: 0, sounds: 'Same note names — sounds an octave below written.' },
  { id: 'recorder', name: 'Recorder', key: 'C', family: 'woodwind', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },

  // ── Strings & fretted ──
  { id: 'violin', name: 'Violin', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'viola', name: 'Viola', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — alto clef at concert pitch.' },
  { id: 'cello', name: 'Cello', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — bass clef at concert pitch.' },
  { id: 'bass', name: 'Double Bass', key: 'C', family: 'strings', offset: 0, sounds: 'Same note names — sounds an octave below written.' },
  { id: 'guitar', name: 'Guitar', key: 'C', family: 'strings', offset: 0, sounds: 'Same note names — sounds an octave below written.' },
  { id: 'bass-gtr', name: 'Bass Guitar', key: 'C', family: 'strings', offset: 0, sounds: 'Same note names — sounds an octave below written.' },
  { id: 'ukulele', name: 'Ukulele', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'mandolin', name: 'Mandolin', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'banjo', name: 'Banjo', key: 'C', family: 'strings', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },

  // ── Keys & mallets ──
  { id: 'piano', name: 'Piano', key: 'C', family: 'keys', offset: 0, sounds: 'Concert pitch — the reference for everyone else.' },
  { id: 'organ', name: 'Organ', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'harp', name: 'Harp', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'accordion', name: 'Accordion', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'celesta', name: 'Celesta', key: 'C', family: 'keys', offset: 0, sounds: 'Same note names — sounds an octave above written.' },
  { id: 'glock', name: 'Glockenspiel', key: 'C', family: 'keys', offset: 0, sounds: 'Same note names — sounds two octaves above written.' },
  { id: 'xylo', name: 'Xylophone', key: 'C', family: 'keys', offset: 0, sounds: 'Same note names — sounds an octave above written.' },
  { id: 'marimba', name: 'Marimba', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'vibes', name: 'Vibraphone', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — plays at concert pitch.' },
  { id: 'timpani', name: 'Timpani', key: 'C', family: 'keys', offset: 0, sounds: 'Non-transposing — concert pitch.' },
]

// ── Spelling ──────────────────────────────────────────────────────────

const FLAT_NAMES = ['C', 'D♭', 'D', 'E♭', 'E', 'F', 'G♭', 'G', 'A♭', 'A', 'B♭', 'B']

/** Natural letter of each pitch class (flat spelling) — for staff placement. */
export const FLAT_LETTER = ['C', 'D', 'D', 'E', 'E', 'F', 'G', 'G', 'A', 'A', 'B', 'B']
const SHARP_NAMES = ['C', 'C♯', 'D', 'D♯', 'E', 'F', 'F♯', 'G', 'G♯', 'A', 'A♯', 'B']

// Fifths value for each preferred major-key spelling (negative = flats)
// pc:    C  Db  D  Eb  E  F  F#  G  Ab  A  Bb  B
const MAJOR_FIFTHS = [0, -5, 2, -3, 4, -1, 6, 1, -4, 3, -2, 5]
// pc 6 is a tie: F♯ (+6) and G♭ (−6) are equally valid.

export type Spelling = 'flat' | 'sharp'

export function noteName(pc: number, pref: Spelling = 'flat'): string {
  const p = ((pc % 12) + 12) % 12
  return (pref === 'flat' ? FLAT_NAMES : SHARP_NAMES)[p]
}

/** Preferred major-key spelling for a pitch class (fewest accidentals). */
export function keySpelling(pc: number): { name: string; fifths: number; tie?: string } {
  const p = ((pc % 12) + 12) % 12
  if (p === 6) return { name: 'F♯ / G♭', fifths: 6, tie: '6♯ = 6♭' }
  return { name: FLAT_NAMES[p], fifths: MAJOR_FIFTHS[p] }
}

/** Preferred minor-key spelling, indexed by tonic pitch class. */
// pc:      C   C♯   D  E♭  E   F  F♯   G  G♯  A  B♭   B
const MINOR_FIFTHS = [-3, 4, -1, -6, 1, -4, 3, -2, 5, 0, -5, 2]

export function minorKeySpelling(pc: number): { name: string; fifths: number } {
  const p = ((pc % 12) + 12) % 12
  const fifths = MINOR_FIFTHS[p]
  const name = fifths > 0 ? SHARP_NAMES[p] : FLAT_NAMES[p]
  return { name, fifths }
}

export function fifthsLabel(fifths: number): string {
  if (fifths === 0) return 'no sharps or flats'
  const n = Math.abs(fifths)
  return `${n} ${fifths > 0 ? (n === 1 ? 'sharp' : 'sharps') : n === 1 ? 'flat' : 'flats'}`
}

const INTERVALS: Record<number, string> = {
  0: 'perfect unison', 1: 'minor 2nd', 2: 'major 2nd', 3: 'minor 3rd',
  4: 'major 3rd', 5: 'perfect 4th', 6: 'tritone', 7: 'perfect 5th',
  8: 'minor 6th', 9: 'major 6th', 10: 'minor 7th', 11: 'major 7th',
}

/** How far the written part sits from concert pitch for this instrument. */
export function writtenIntervalLabel(inst: Instrument): string {
  const o = ((inst.offset % 12) + 12) % 12
  if (o === 0) return 'Written part = concert pitch'
  if (o <= 6) return `Written part = a ${INTERVALS[o]} above concert`
  return `Written part = a ${INTERVALS[12 - o]} below concert`
}

/** Transpose a pitch class for an instrument. */
export function transpose(pc: number, inst: Instrument, toWritten: boolean): number {
  const o = toWritten ? inst.offset : -inst.offset
  return (((pc + o) % 12) + 12) % 12
}

/** Transpose a pitch class from one instrument's written pitch to another's. */
export function transposeBetween(pc: number, from: Instrument, to: Instrument): number {
  return (((pc - from.offset + to.offset) % 12) + 12) % 12
}

// ── Chords ────────────────────────────────────────────────────────────

export interface ChordQuality {
  id: string
  suffix: string // '' for major
  label: string
  intervals: number[] // semitones from root
}

export const CHORDS: ChordQuality[] = [
  { id: 'power5', suffix: '5', label: 'Power chord (5)', intervals: [0, 7] },
  { id: 'maj', suffix: '', label: 'Major', intervals: [0, 4, 7] },
  { id: 'min', suffix: 'm', label: 'Minor', intervals: [0, 3, 7] },
  { id: 'dom7', suffix: '7', label: 'Dominant 7', intervals: [0, 4, 7, 10] },
  { id: 'maj7', suffix: 'maj7', label: 'Major 7', intervals: [0, 4, 7, 11] },
  { id: 'min7', suffix: 'm7', label: 'Minor 7', intervals: [0, 3, 7, 10] },
  { id: 'min7b5', suffix: 'm7♭5', label: 'Half-diminished', intervals: [0, 3, 6, 10] },
  { id: 'dim7', suffix: '°7', label: 'Diminished 7', intervals: [0, 3, 6, 9] },
  { id: 'aug', suffix: 'aug', label: 'Augmented', intervals: [0, 4, 8] },
  { id: 'sus4', suffix: 'sus4', label: 'Sus 4', intervals: [0, 5, 7] },
  { id: 'sus2', suffix: 'sus2', label: 'Sus 2', intervals: [0, 2, 7] },
  { id: 'add9', suffix: 'add9', label: 'Add 9', intervals: [0, 4, 7, 14] },
  { id: 'six', suffix: '6', label: 'Sixth', intervals: [0, 4, 7, 9] },
  { id: 'nine', suffix: '9', label: 'Ninth', intervals: [0, 4, 7, 10, 14] },
  { id: 'min9', suffix: 'm9', label: 'Minor 9', intervals: [0, 3, 7, 10, 14] },
  { id: 'thirteen', suffix: '13', label: 'Thirteenth', intervals: [0, 4, 7, 10, 14, 17, 21] },
  { id: 'sevenflat9', suffix: '7♭9', label: '7 flat 9', intervals: [0, 4, 7, 10, 13] },
]

/** Spell a chord's notes for a given instrument's written part. */
export function chordNotes(rootPc: number, chord: ChordQuality, inst: Instrument): number[] {
  return chord.intervals.map((i) => transpose((rootPc + i) % 12, inst, true))
}

// ── Chord spelling (real note names, not just pitch classes) ─────────

const LETTERS = ['C', 'D', 'E', 'F', 'G', 'A', 'B']
const LETTER_PC: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }

/** Diatonic letter-steps each chord interval sits above the root. */
export const INTERVAL_STEPS: Record<number, number> = {
  0: 0, 1: 1, 2: 1, 3: 2, 4: 2, 5: 3, 6: 4, 7: 4, 8: 4, 9: 5, 10: 6,
  11: 6, 12: 0, 13: 1, 14: 1, 15: 2, 16: 2, 17: 3, 18: 4, 19: 4, 20: 5, 21: 5,
}

/** Root name for a pitch class; the F♯/G♭ tie follows the user's spelling toggle. */
export function rootNameFor(pc: number, spelling: Spelling = 'flat'): string {
  const p = ((pc % 12) + 12) % 12
  if (p === 6) return spelling === 'sharp' ? 'F♯' : 'G♭'
  return FLAT_NAMES[p]
}

/** Full chord symbol, e.g. "C9", "F♯m7", "B♭maj7". */
export function chordName(rootPc: number, chord: ChordQuality, spelling: Spelling = 'flat'): string {
  return rootNameFor(rootPc, spelling) + chord.suffix
}

/**
 * Spell every tone of a chord with correct note letters, e.g.
 * C dominant 9 → ["C", "E", "G", "B♭", "D"].
 */
export function spellChordTones(rootPc: number, chord: ChordQuality, spelling: Spelling = 'flat'): string[] {
  const root = rootNameFor(rootPc, spelling)
  const rootLetterIdx = LETTERS.indexOf(root[0])
  return chord.intervals.map((semi) => {
    const steps = INTERVAL_STEPS[semi] ?? 0
    const letterIdx = (rootLetterIdx + steps) % 7
    const naturalPc = LETTER_PC[LETTERS[letterIdx]]
    let acc = (((rootPc + semi) % 12) - naturalPc) % 12
    if (acc > 6) acc -= 12
    if (acc < -6) acc += 12
    const accStr = acc === 0 ? '' : acc > 0 ? '♯'.repeat(acc) : '♭'.repeat(-acc)
    return LETTERS[letterIdx] + accStr
  })
}

/** Spell a chord's notes mapped from one instrument's written chord to another's. */
export function chordNotesBetween(rootPc: number, chord: ChordQuality, from: Instrument, to: Instrument): number[] {
  return chord.intervals.map((i) => transposeBetween((rootPc + i) % 12, from, to))
}

export function familyOf(inst: Instrument): Family {
  return FAMILIES.find((f) => f.id === inst.family)!
}

```


### `src/lib/a11y.ts`

```ts
// ── SCN Technologies signature accessibility + language layer ───────

export type Lang = 'en' | 'es'

export interface A11yPrefs {
  lang: Lang
  colorblind: boolean // shapes + outlines, never color alone
  calm: boolean // stop motion / floating notes
  largeText: boolean
  dark: boolean
}

export const DEFAULT_PREFS: A11yPrefs = {
  lang: 'en',
  colorblind: false,
  calm: false,
  largeText: false,
  dark: false,
}

const KEY = 'transpose-a11y'

export function loadPrefs(): A11yPrefs {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return DEFAULT_PREFS
    return { ...DEFAULT_PREFS, ...JSON.parse(raw) }
  } catch {
    return DEFAULT_PREFS
  }
}

export function savePrefs(p: A11yPrefs) {
  try {
    localStorage.setItem(KEY, JSON.stringify(p))
  } catch {
    /* private mode etc. — preferences just won't persist */
  }
}

/** Apply prefs to the document root as classes. */
export function applyPrefs(p: A11yPrefs) {
  const el = document.documentElement
  el.classList.toggle('a11y-cb', p.colorblind)
  el.classList.toggle('calm', p.calm)
  el.classList.toggle('large-text', p.largeText)
  el.classList.toggle('dark', p.dark)
  el.lang = p.lang
}

const en = {
  appName: 'Transpose',
  heroTitleA: 'The piano is a C instrument.',
  heroTitleB: 'Its key is the key of the music.',
  heroSub: "Here's what every instrument and voice plays from there.",
  tourBanner: 'New here? Watch the quick tour — it shows the app being used.',
  tourCaption: 'Watch the quick tour.',
  tourHint: 'Tap anything blue with a ▾, tap a note — the answer appears.',
  tourAria: 'Short demo: tap an instrument, tap a note, read the answer',
  offlineReady: 'Offline ready — works without internet once loaded',
  a11yOpen: 'Accessibility & language options',
  a11yTitle: 'Accessibility & Language',
  a11yIntro: 'SCN Technologies signature options — set once, remembered on this device.',
  optColorblind: 'Colorblind-friendly',
  optColorblindSub: 'Shapes on the colored dots, bold outlines on selections — never color alone',
  optCalm: 'Calm mode',
  optCalmSub: 'Stops floating notes, glows, and motion',
  optLargeText: 'Large text',
  optLargeTextSub: 'Bigger type throughout the app',
  optDark: 'Dark mode',
  optDarkSub: 'Easy on the eyes in a dark sanctuary',
  optLang: 'Language / Idioma',
  close: 'Done',
  s1Title: 'Set the key',
  s1Hint: 'the source — piano by default',
  s1Steps: [
    'Tap the blue box with a ▾ to change who is leading — the piano by default.',
    'Tap Major, Minor, Chord, or Note — then tap a key below.',
    'The whole band below follows whatever you set here.',
  ],
  s2Title: 'The band plays',
  s2Hint: 'no limit — add everybody',
  s2Steps: [
    'The first player is the tenor sax — tap its blue box to make it anybody.',
    'Press + Add player for more — two altos, a singer and a banjo, anything. Each new player gets their own color.',
    'Horns and voices each take one note (tap “Plays the…” to choose which); keys and guitar take the whole chord. See everyone on the staff below.',
  ],
  tapToChange: '( tap to change )',
  ifThe: 'If the',
  isPlaying: 'is playing',
  isSinging: 'is singing',
  plays: 'plays',
  sings: 'sings',
  a: 'a',
  on: 'on',
  the: 'the',
  majorKey: 'Major key',
  minorKey: 'Minor key',
  chord: 'Chord',
  note: 'Note',
  theNote: 'the note',
  rootKeyOfMusic: 'the root — the key of the music',
  writtenRoot: "'s written root",
  writtenNoteLabel: "'s written note",
  pianoCInst: 'Piano — C instrument',
  whichIsConcert: 'which is concert',
  majorKeyWord: 'major',
  minorKeyWord: 'minor',
  keyWord: 'key',
  tieLabel: '6 sharps = 6 flats',
  addLabel: 'Add an instrument or voice',
  addPlayer: '+ Add player',
  sourceLabel: 'The key / chord comes from',
  sourceDefault: 'The piano — C instrument (default)',
  theirPart: ' — their written part',
  qualityLabel: 'Key or chord type',
  bandRootPiano: 'The key of the music (what the piano plays)',
  bandRootSource: "'s written root",
  sourcePrefix: 'Source:',
  sourcePianoText: 'Piano — C instrument · the key of the music',
  sourcePlayerSuffix: ' — everything below is their transposed part',
  actualChord: 'Piano / guitar — the actual chord',
  writtenNoteOfChord: 'written note',
  ofTheChord: 'of the chord',
  playsThe: 'Plays the',
  emptyBand: 'Nobody in the band yet — pick an instrument or voice above and hit “Add player”.',
  footerText:
    "The piano is a C instrument — its key is the key of the music, and everyone else transposes from there. Horns and voices each take one note of the chord; keys and fretted instruments can play the whole thing. Guitar, bass, piccolo, and tenor voices share the piano's note names and only shift an octave.",
  footerMark: 'Built by SCN Technologies — accessible by design.',
  copyright: '© 2026 SCN Technologies. All rights reserved.',
  yourNoteLineA: 'You play',
  theWord: 'the',
  pianoPlays: 'Piano plays',
  inKey: 'in',
  accidentalSpelling: 'Accidental spelling',
  whatPlaying: 'What are they playing',
  chordType: 'Chord type',
  chooseInst: 'Choose an instrument or voice',
  getStarted: 'Get started',
  landingKicker: 'The 60-second tour',
  landingLine: 'Every instrument. Every voice. One answer.',
  landingSub: 'Watch it work, then jump in — free, no sign-up, works offline.',
  staffTitle: 'The band on the staff',
  playsWholeChord: 'plays the whole chord',
  concertNote: 'the actual chord at concert pitch',
  soundOn: 'Sound on',
  soundOff: 'Tap for sound',
}

const es: typeof en = {
  appName: 'Transpose',
  heroTitleA: 'El piano es un instrumento en Do.',
  heroTitleB: 'Su tono es el tono de la música.',
  heroSub: 'Esto es lo que toca cada instrumento y voz a partir de ahí.',
  tourBanner: '¿Primera vez? Mira el recorrido rápido — muestra la app en uso.',
  tourCaption: 'Mira el recorrido rápido.',
  tourHint: 'Toca cualquier caja azul con ▾, toca una nota — la respuesta aparece.',
  tourAria: 'Demo corta: toca un instrumento, toca una nota, lee la respuesta',
  offlineReady: 'Lista sin internet — funciona sin conexión una vez cargada',
  a11yOpen: 'Opciones de accesibilidad e idioma',
  a11yTitle: 'Accesibilidad e Idioma',
  a11yIntro: 'Opciones insignia de SCN Technologies — se guardan en este dispositivo.',
  optColorblind: 'Para daltónicos',
  optColorblindSub: 'Formas en los puntos de color, contornos en la selección — nunca solo color',
  optCalm: 'Modo tranquilo',
  optCalmSub: 'Detiene las notas flotantes y el movimiento',
  optLargeText: 'Texto grande',
  optLargeTextSub: 'Letra más grande en toda la app',
  optDark: 'Modo oscuro',
  optDarkSub: 'Suave para los ojos en un santuario oscuro',
  optLang: 'Idioma / Language',
  close: 'Listo',
  s1Title: 'Fija el tono',
  s1Hint: 'la fuente — piano por defecto',
  s1Steps: [
    'Toca la caja azul con ▾ para cambiar quién guía — el piano por defecto.',
    'Toca Mayor, Menor, Acorde o Nota — luego toca un tono abajo.',
    'Toda la banda abajo sigue lo que fijes aquí.',
  ],
  s2Title: 'La banda toca',
  s2Hint: 'sin límite — agrega a todos',
  s2Steps: [
    'El primer músico es el sax tenor — toca su caja azul para cambiarlo.',
    'Pulsa + Agregar para más — cada músico nuevo recibe su propio color.',
    'Metales y voces tocan una nota (toca “Toca el…” para elegir cuál); piano y guitarra tocan el acorde completo. Mira a todos en el pentagrama abajo.',
  ],
  tapToChange: '( toca para cambiar )',
  ifThe: 'Si el',
  isPlaying: 'está tocando',
  isSinging: 'está cantando',
  plays: 'toca',
  sings: 'canta',
  a: 'un',
  on: 'en',
  the: 'el',
  majorKey: 'Tono mayor',
  minorKey: 'Tono menor',
  chord: 'Acorde',
  note: 'Nota',
  theNote: 'la nota',
  rootKeyOfMusic: 'la tónica — el tono de la música',
  writtenRoot: ' — tónica escrita de ',
  writtenNoteLabel: ' — nota escrita de ',
  pianoCInst: 'Piano — instrumento en Do',
  whichIsConcert: 'que en concierto es',
  majorKeyWord: 'mayor',
  minorKeyWord: 'menor',
  keyWord: 'tono',
  tieLabel: '6 sostenidos = 6 bemoles',
  addLabel: 'Agrega un instrumento o voz',
  addPlayer: '+ Agregar',
  sourceLabel: 'El tono / acorde viene de',
  sourceDefault: 'El piano — instrumento en Do (por defecto)',
  theirPart: ' — su partitura',
  qualityLabel: 'Tono o tipo de acorde',
  bandRootPiano: 'El tono de la música (lo que toca el piano)',
  bandRootSource: ' — tónica escrita',
  sourcePrefix: 'Origen:',
  sourcePianoText: 'Piano — instrumento en Do · el tono de la música',
  sourcePlayerSuffix: ' — todo lo de abajo es su parte transportada',
  actualChord: 'Piano / guitarra — el acorde real',
  writtenNoteOfChord: 'nota escrita',
  ofTheChord: 'del acorde',
  playsThe: 'Toca el',
  emptyBand: 'Aún no hay nadie en la banda — elige arriba y pulsa “Agregar”.',
  footerText:
    'El piano es un instrumento en Do — su tono es el tono de la música, y todos los demás transportan a partir de ahí. Metales y voces tocan una nota del acorde; teclas y cuerdas pulsadas pueden tocarlo completo. Guitarra, bajo, flautín y tenores comparten los nombres de las notas del piano y solo cambian de octava.',
  footerMark: 'Hecho por SCN Technologies — accesible por diseño.',
  copyright: '© 2026 SCN Technologies. Todos los derechos reservados.',
  yourNoteLineA: 'Tocas',
  theWord: 'el',
  pianoPlays: 'El piano toca',
  inKey: 'en',
  accidentalSpelling: 'Escritura de alteraciones',
  whatPlaying: 'Qué están tocando',
  chordType: 'Tipo de acorde',
  chooseInst: 'Elige un instrumento o voz',
  getStarted: 'Comenzar',
  landingKicker: 'El recorrido de 60 segundos',
  landingLine: 'Cada instrumento. Cada voz. Una respuesta.',
  landingSub: 'Míralo funcionar y entra — gratis, sin registro, funciona sin internet.',
  staffTitle: 'La banda en el pentagrama',
  playsWholeChord: 'toca el acorde completo',
  concertNote: 'el acorde real en concierto',
  soundOn: 'Con sonido',
  soundOff: 'Toca para sonido',
}

export const STRINGS: Record<Lang, typeof en> = { en, es }
export type Strings = typeof en

```


### `src/components/StaffChord.tsx`

```tsx
import { FLAT_LETTER, INTERVAL_STEPS } from '@/lib/music'

/** True treble clef outline (from the Noto Music font), normalized: the G line
 *  (2nd staff line from the bottom) passes through svg y = 0. */
const CLEF_D =
  'M31.4 -55.1Q30 -60.4 29.1 -65.6Q28.2 -70.8 28.2 -76.2Q28.2 -80.9 28.9 -85.1Q29.5 -89.2 30.7 -92.7Q32 -96.7 34.1 -100.2Q36.2 -103.8 38.6 -106.1Q40.9 -108.4 42.7 -108.4Q45.1 -108.4 49.3 -99.9Q51.4 -95.6 52.4 -90.6Q53.4 -85.6 53.4 -79.9Q53.4 -72.8 51.5 -65.8Q49.6 -58.7 46 -52.5Q42.3 -46.3 37.2 -41.6L40.7 -24.8Q42.2 -25 43.2 -25.1Q44.2 -25.2 44.7 -25.2Q50.8 -25.2 55.6 -21.8Q60.4 -18.3 63.3 -12.7Q66.1 -7.1 66.1 -0.4Q66.1 7.3 62.2 13.5Q58.2 19.6 50.3 22.5Q50.8 24.2 53.2 36.7Q53.8 39.7 54.1 41.5Q54.4 43.2 54.5 44.5Q54.6 45.8 54.6 47.5Q54.6 52.5 52.2 56.5Q49.7 60.4 45.6 62.6Q41.4 64.8 36.3 64.8Q31.1 64.8 27.1 62.9Q23.1 60.9 20.8 57.5Q18.5 54 18.5 49.5Q18.5 44.7 21.1 41.5Q23.8 38.3 28.7 38.3Q32.9 38.3 35.5 41.4Q38.2 44.4 38.2 48.6Q38.2 52.2 35.7 54.9Q33.2 57.6 29.2 57.6H28.2Q30.8 61.5 36.4 61.5Q43.3 61.5 47.2 57Q51.1 52.5 51.1 45.5Q51.1 43.8 50.7 41Q50.3 38.1 49.3 34.1Q48.3 30.1 47.8 27.5Q47.2 24.9 47 23.8Q43.6 24.8 39 24.8Q30.4 24.8 22.2 19.8Q14.2 14.8 9.6 6.6Q5 -1.6 5 -11.1Q5 -20.1 9.1 -28Q13.2 -35.9 19.2 -42.5Q25.3 -49.1 31.4 -55.1ZM34.1 -57.6Q36.4 -58.8 39 -62.1Q41.6 -65.3 44 -69.5Q46.4 -73.7 47.9 -78Q49.4 -82.2 49.4 -85.6Q49.4 -89.2 48.3 -91.3Q47.2 -93.4 44.5 -93.4Q42.1 -93.4 39.9 -91.2Q37.6 -89 35.9 -85.3Q34.1 -81.7 33.1 -77.2Q32.1 -72.7 32.1 -68Q32.1 -64.8 32.8 -62.2Q33.4 -59.6 34.1 -57.6ZM39.8 -12.9Q37.1 -12.3 34.7 -10.4Q32.3 -8.4 30.9 -5.7Q29.4 -2.9 29.4 0.2Q29.4 2.7 30.7 5.3Q32 8 33.9 9.6Q35.2 10.8 36.5 11.4Q38 12.1 38 12.7Q38 13 37 13.3Q33.2 12.4 30.2 9.9Q27.1 7.4 25.4 3.8Q23.6 0.3 23.6 -3.7Q23.6 -8 25.4 -12Q27.1 -16 30.2 -19.2Q33.4 -22.4 37.4 -24L34.5 -39.1Q22.9 -29.7 17.5 -20.7Q12 -11.6 12 -2.7Q12 3.8 15.4 9.4Q18.8 15 24.7 18.4Q30.6 21.9 38 21.9Q40 21.9 42 21.5Q44.1 21.1 46.4 20.5ZM49.5 19.5Q59.3 15.3 59.3 2.3Q59.3 -2 57.1 -5.6Q54.9 -9.1 51.2 -11.2Q47.5 -13.3 42.9 -13.3Z'

export interface StaffTone {
  semitones: number // interval above root
  color: string // owner player's color (or neutral)
  label: string // legend label, e.g. "Tenor Saxophone"
}

const LETTER_PC: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }
const LETTERS = ['C', 'D', 'E', 'F', 'G', 'A', 'B']

interface Placed {
  pos: number // absolute diatonic position (C4 = 28)
  acc: string // '', '♭', '♯', '♭♭'…
  color: string
  label: string
}

/**
 * Draws the band's chord on a treble-clef staff. Each notehead takes the color
 * of the player who owns that tone; chord players get the bracket in the legend.
 */
export function StaffChord({
  rootPc,
  intervals,
  tones,
  bracketColor,
  bracketLabel,
  t,
}: {
  rootPc: number
  intervals: number[]
  tones: StaffTone[]
  bracketColor?: string
  bracketLabel?: string
  t: { staffTitle: string; playsWholeChord: string; concertNote: string }
}) {
  const rootLetter = LETTERS.indexOf(FLAT_LETTER[((rootPc % 12) + 12) % 12])
  const rootOctave = rootLetter >= 4 ? 3 : 4 // keep tall chords on the staff
  const rootAbs = rootOctave * 7 + rootLetter

  const placed: Placed[] = intervals.map((s, i) => {
    const pos = rootAbs + Math.floor(s / 12) * 7 + INTERVAL_STEPS[s % 12]
    const naturalPc = LETTER_PC[LETTERS[pos % 7]]
    let diff = (((rootPc + s) % 12) - naturalPc) % 12
    if (diff > 6) diff -= 12
    if (diff < -6) diff += 12
    const acc = diff === 0 ? '' : diff > 0 ? '♯'.repeat(diff) : '♭'.repeat(-diff)
    const tone = tones[i]
    return { pos, acc, color: tone?.color ?? 'hsl(var(--foreground))', label: tone?.label ?? '' }
  })

  // ── Geometry ──
  const STEP = 5 // px per diatonic step
  const BOTTOM = 30 // diatonic pos of the bottom staff line (E4)
  const minPos = Math.min(...placed.map((p) => p.pos))
  const maxPos = Math.max(...placed.map((p) => p.pos))
  const topPad = Math.max(0, maxPos - (BOTTOM + 8)) * STEP + 14
  const botPad = Math.max(0, BOTTOM - 2 - minPos) * STEP + 14
  const staffH = 8 * STEP
  const H = topPad + staffH + botPad
  const yOf = (pos: number) => topPad + staffH - (pos - BOTTOM) * STEP

  const X_LINES = 66
  const X_NOTE = 150
  const W = 340

  // seconds (pos diff 1) get left/right notehead offsets
  const sorted = [...placed].sort((a, b) => a.pos - b.pos)
  const xOf = new Map<Placed, number>()
  sorted.forEach((p, i) => {
    const prev = sorted[i - 1]
    xOf.set(p, prev && p.pos - prev.pos === 1 && xOf.get(prev) === X_NOTE ? X_NOTE + 11 : X_NOTE)
  })

  // ledger lines needed
  const ledgers: { y: number; x: number }[] = []
  for (const p of placed) {
    const x = xOf.get(p)!
    if (p.pos <= BOTTOM - 2) {
      for (let lp = BOTTOM - 2; lp >= p.pos; lp -= 2) ledgers.push({ y: yOf(lp), x })
    }
    if (p.pos >= BOTTOM + 10) {
      for (let lp = BOTTOM + 10; lp <= p.pos; lp += 2) ledgers.push({ y: yOf(lp), x })
    }
  }

  // legend entries (unique colors in chord order)
  const seen = new Set<string>()
  const legend = placed
    .filter((p) => p.label)
    .filter((p) => (seen.has(p.label) ? false : (seen.add(p.label), true)))

  return (
    <div>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="w-full"
        role="img"
        aria-label={`${t.staffTitle}: ${t.concertNote}`}
      >
        {/* staff lines */}
        {[0, 2, 4, 6, 8].map((s) => (
          <line
            key={s}
            x1={X_LINES - 34}
            x2={W - 14}
            y1={yOf(BOTTOM + s)}
            y2={yOf(BOTTOM + s)}
            stroke="hsl(var(--foreground))"
            strokeWidth="1"
            opacity="0.75"
          />
        ))}
        {/* treble clef — G line (pos BOTTOM+2) through the spiral */}
        <g transform={`translate(8, ${yOf(BOTTOM + 2)}) scale(${(staffH * 1.72) / 173.2})`}>
          <path d={CLEF_D} fill="hsl(var(--foreground))" />
        </g>
        {/* ledger lines */}
        {ledgers.map((l, i) => (
          <line
            key={i}
            x1={l.x - 11}
            x2={l.x + 11}
            y1={l.y}
            y2={l.y}
            stroke="hsl(var(--foreground))"
            strokeWidth="1"
            opacity="0.75"
          />
        ))}
        {/* noteheads + accidentals */}
        {placed.map((p, i) => {
          const x = xOf.get(p)!
          const y = yOf(p.pos)
          return (
            <g key={i}>
              {p.acc && (
                <text
                  x={x - 16}
                  y={y + 5}
                  fontSize="15"
                  fontWeight="700"
                  fill="hsl(var(--foreground))"
                  className="note-display"
                >
                  {p.acc}
                </text>
              )}
              <ellipse
                cx={x}
                cy={y}
                rx="6.2"
                ry="4.4"
                transform={`rotate(-18 ${x} ${y})`}
                fill={p.color}
                stroke="hsl(var(--foreground))"
                strokeWidth="0.75"
              />
            </g>
          )
        })}
        {/* whole-chord bracket for keys/guitar players */}
        {bracketColor && (
          <path
            d={`M ${W - 40} ${yOf(maxPos) - 10} q 8 0 8 8 l 0 ${Math.max(10, yOf(minPos) - yOf(maxPos) + 4)} q 0 8 -8 8`}
            fill="none"
            stroke={bracketColor}
            strokeWidth="3"
            strokeLinecap="round"
          />
        )}
      </svg>

      {/* legend — who plays what */}
      <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1.5">
        {bracketColor && bracketLabel && (
          <li className="flex items-center gap-1.5 text-xs text-foreground/80">
            <span className="inline-block h-2.5 w-2.5 rounded-full border-2" style={{ borderColor: bracketColor }} aria-hidden />
            <span className="font-semibold">{bracketLabel}</span>
            <span className="text-muted-foreground">· {t.playsWholeChord}</span>
          </li>
        )}
        {legend.map((p) => (
          <li key={p.label} className="flex items-center gap-1.5 text-xs text-foreground/80">
            <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: p.color }} aria-hidden />
            <span className="font-semibold">{p.label}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

```


### `src/components/A11yPanel.tsx`

```tsx
import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import type { A11yPrefs, Strings } from '@/lib/a11y'

function Toggle({
  checked,
  onChange,
  label,
  sub,
}: {
  checked: boolean
  onChange: (v: boolean) => void
  label: string
  sub: string
}) {
  return (
    <div className="flex items-center justify-between gap-3 py-3">
      <div className="min-w-0">
        <p className="text-sm font-semibold text-foreground">{label}</p>
        <p className="mt-0.5 text-xs leading-snug text-muted-foreground">{sub}</p>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        onClick={() => onChange(!checked)}
        className={cn(
          'focus-ring relative h-8 w-14 shrink-0 rounded-full border transition-colors duration-200',
          checked ? 'border-primary bg-primary' : 'border-border bg-muted'
        )}
      >
        <span
          aria-hidden
          className={cn(
            'absolute top-1 h-6 w-6 rounded-full bg-card shadow transition-transform duration-200',
            checked ? 'translate-x-6' : 'translate-x-1'
          )}
        />
      </button>
    </div>
  )
}

export function A11yPanel({
  prefs,
  setPrefs,
  t,
}: {
  prefs: A11yPrefs
  setPrefs: (p: A11yPrefs) => void
  t: Strings
}) {
  const [open, setOpen] = useState(false)
  const panelRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    const onTap = (e: PointerEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('keydown', onKey)
    document.addEventListener('pointerdown', onTap)
    return () => {
      document.removeEventListener('keydown', onKey)
      document.removeEventListener('pointerdown', onTap)
    }
  }, [open])

  return (
    <div className="relative" ref={panelRef}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-label={t.a11yOpen}
        title={t.a11yOpen}
        className="focus-ring flex h-11 w-11 items-center justify-center rounded-full border border-border bg-card text-foreground shadow-sm transition-all duration-150 hover:border-primary hover:text-primary active:scale-95"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden>
          <circle cx="12" cy="5" r="2" fill="currentColor" />
          <path
            d="M4 9.5c2.7.8 5.3 1.2 8 1.2s5.3-.4 8-1.2M12 11v4m0 0-3.5 6M12 15l3.5 6"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>

      {open && (
        <div
          role="dialog"
          aria-label={t.a11yTitle}
          className="absolute right-0 top-[52px] z-50 w-[320px] max-w-[calc(100vw-2rem)] rounded-xl border border-border bg-card p-4 shadow-xl shadow-foreground/10"
        >
          <p className="font-serif text-base font-semibold tracking-tight">{t.a11yTitle}</p>
          <p className="mt-1 text-[11px] leading-snug text-muted-foreground">{t.a11yIntro}</p>

          <div className="mt-2 divide-y divide-border/60">
            <Toggle
              checked={prefs.colorblind}
              onChange={(v) => setPrefs({ ...prefs, colorblind: v })}
              label={t.optColorblind}
              sub={t.optColorblindSub}
            />
            <Toggle
              checked={prefs.calm}
              onChange={(v) => setPrefs({ ...prefs, calm: v })}
              label={t.optCalm}
              sub={t.optCalmSub}
            />
            <Toggle
              checked={prefs.largeText}
              onChange={(v) => setPrefs({ ...prefs, largeText: v })}
              label={t.optLargeText}
              sub={t.optLargeTextSub}
            />
            <Toggle
              checked={prefs.dark}
              onChange={(v) => setPrefs({ ...prefs, dark: v })}
              label={t.optDark}
              sub={t.optDarkSub}
            />
          </div>

          <div className="mt-1 border-t border-border/60 pt-3">
            <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              {t.optLang}
            </p>
            <div className="flex rounded-md border border-border bg-background p-1" role="radiogroup" aria-label={t.optLang}>
              {(['en', 'es'] as const).map((l) => (
                <button
                  key={l}
                  type="button"
                  role="radio"
                  aria-checked={prefs.lang === l}
                  onClick={() => setPrefs({ ...prefs, lang: l })}
                  className={cn(
                    'focus-ring flex h-10 flex-1 items-center justify-center rounded text-sm font-semibold transition-colors',
                    prefs.lang === l ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                  )}
                >
                  {l === 'en' ? 'English' : 'Español'}
                </button>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={() => setOpen(false)}
            className="focus-ring mt-4 h-11 w-full rounded-md bg-primary text-sm font-bold text-primary-foreground transition-all duration-150 hover:brightness-110 active:scale-95"
          >
            {t.close}
          </button>
        </div>
      )}
    </div>
  )
}

```


### `src/components/Reveal.tsx`

```tsx
import { useEffect, useRef, useState, type ReactNode } from 'react'
import { cn } from '@/lib/utils'

/** Fade-and-slide reveal on scroll, like a polished scroll site. */
export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode
  className?: string
  delay?: number
}) {
  const ref = useRef<HTMLDivElement>(null)
  const [shown, setShown] = useState(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setShown(true)
      return
    }
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setShown(true)
          io.disconnect()
        }
      },
      { threshold: 0.1, rootMargin: '0px 0px -8% 0px' }
    )
    io.observe(el)
    return () => io.disconnect()
  }, [])

  return (
    <div
      ref={ref}
      style={{ transitionDelay: `${delay}ms` }}
      className={cn(
        'transition-all duration-700 ease-reveal will-change-transform',
        shown ? 'translate-y-0 opacity-100 blur-0' : 'translate-y-4 opacity-0 blur-[8px]',
        className
      )}
    >
      {children}
    </div>
  )
}

```


### `src/App.tsx`

```tsx
import { Routes, Route, Navigate } from 'react-router'
import Landing from './pages/Landing'
import Home from './pages/Home'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/app" element={<Home />} />
      {/* Static hosts have no rewrites — any unknown path lands on the homepage */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

```


### `src/pages/Landing.tsx`

```tsx
import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router'
import { Reveal } from '@/components/Reveal'
import { A11yPanel } from '@/components/A11yPanel'
import { applyPrefs, loadPrefs, savePrefs, STRINGS, type A11yPrefs } from '@/lib/a11y'

export default function Landing() {
  const navigate = useNavigate()
  const [prefs, setPrefsState] = useState<A11yPrefs>(() => loadPrefs())
  const videoRef = useRef<HTMLVideoElement>(null)
  const t = STRINGS[prefs.lang]

  function setPrefs(next: A11yPrefs) {
    setPrefsState(next)
    savePrefs(next)
  }
  useEffect(() => {
    applyPrefs(prefs)
  }, [prefs])
  // Music autoplay — the song starts the moment the page opens.
  // 1) Try playing the video WITH sound immediately (browsers allow this for
  //    returning/engaged visitors; Chrome's Media Engagement Index, installed
  //    PWA, or a prior visit all grant it).
  // 2) If blocked (first-ever visit on strict browsers), start muted and arm
  //    one-time listeners that flip sound on at the very first touch/scroll/key —
  //    nobody has to hunt for a button; the music simply starts with the page.
  useEffect(() => {
    const v = videoRef.current
    if (!v) return
    const arm = () => {
      const unmute = () => {
        if (v.muted) {
          v.muted = false
          v.volume = 1
          v.play().catch(() => {})
        }
        detach()
      }
      const detach = () => {
        window.removeEventListener('pointerdown', unmute)
        window.removeEventListener('touchstart', unmute)
        window.removeEventListener('scroll', unmute)
        window.removeEventListener('keydown', unmute)
      }
      window.addEventListener('pointerdown', unmute, { passive: true })
      window.addEventListener('touchstart', unmute, { passive: true })
      window.addEventListener('scroll', unmute, { passive: true })
      window.addEventListener('keydown', unmute)
    }
    v.muted = false
    v.volume = 1
    v.play().catch(() => {
      v.muted = true
      v.play().catch(() => {})
      arm()
    })
  }, [])

  return (
    <div className="min-h-dvh">
      <div className="grain" aria-hidden />
      <div className="mx-auto w-full max-w-2xl px-4 pb-16 sm:px-6">
        {/* Header */}
        <header className="relative flex items-center justify-center border-b border-border py-5">
          <div className="absolute left-0 hidden items-center gap-1.5 rounded-full border border-primary/25 bg-secondary px-2.5 py-1 sm:flex">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" aria-hidden />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-secondary-foreground">
              {t.offlineReady}
            </span>
          </div>
          <div className="absolute right-0">
            <A11yPanel prefs={prefs} setPrefs={setPrefs} t={t} />
          </div>
          <div className="flex items-center gap-2.5">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden className="text-primary">
              <path d="M9 18V5l12-2v13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="6" cy="18" r="3" stroke="currentColor" strokeWidth="2" />
              <circle cx="18" cy="16" r="3" stroke="currentColor" strokeWidth="2" />
            </svg>
            <span className="font-serif text-lg font-semibold tracking-tight">{t.appName}</span>
          </div>
        </header>

        {/* Landing — tour video with music + Get Started */}
        <div className="relative overflow-hidden">
          <div
            aria-hidden
            className="kenburns pointer-events-none absolute -inset-10"
            style={{
              background:
                'radial-gradient(42% 55% at 22% 18%, hsl(223 90% 88% / 0.9), transparent 70%), radial-gradient(38% 48% at 82% 30%, hsl(221 96% 31% / 0.14), transparent 70%), radial-gradient(50% 42% at 50% 88%, hsl(41 60% 80% / 0.55), transparent 72%)',
            }}
          />
          {[
            { left: '6%', size: 20, dur: '11s', delay: '0s' },
            { left: '26%', size: 14, dur: '14s', delay: '3.5s' },
            { left: '72%', size: 24, dur: '12s', delay: '1.2s' },
            { left: '88%', size: 15, dur: '15s', delay: '5s' },
            { left: '48%', size: 12, dur: '13s', delay: '7s' },
          ].map((n, i) => (
            <svg
              key={i}
              aria-hidden
              className="float-note"
              style={{ left: n.left, width: n.size, height: n.size * 1.35, animationDuration: n.dur, animationDelay: n.delay }}
              viewBox="0 0 24 32"
              fill="none"
            >
              <path
                d="M9 26V6l12-2.5V22"
                stroke="hsl(38 60% 45%)"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <ellipse cx="6.5" cy="26" rx="4" ry="3" fill="hsl(38 60% 45%)" />
              <ellipse cx="18.5" cy="22" rx="4" ry="3" fill="hsl(38 60% 45%)" />
            </svg>
          ))}
          <Reveal className="relative pb-8 pt-6 text-center sm:pb-10 sm:pt-10">
            <p className="note-display text-[11px] font-bold uppercase tracking-[0.22em] text-primary">
              {t.landingKicker}
            </p>
            <h1 className="mx-auto mt-3 max-w-md font-serif text-3xl font-semibold leading-tight tracking-tight sm:text-4xl">
              {t.landingLine}
            </h1>
            <p className="mx-auto mt-3 max-w-sm text-base leading-relaxed text-muted-foreground">
              {t.landingSub}
            </p>

            <div className="mx-auto mt-6 max-w-sm">
              <video
                ref={videoRef}
                className="w-full rounded-xl border border-primary/25 bg-card object-contain shadow-lg shadow-primary/10"
                src="./demo.mp4"
                autoPlay
                loop
                playsInline
                preload="auto"
                aria-label={t.tourAria}
              />
              <p className="mt-2 text-center text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
                ♪ Every Voice, One Answer — SCN Technologies
              </p>
            </div>

            <div className="mt-6 flex flex-col items-center gap-2">
              <button
                type="button"
                onClick={() => navigate('/app')}
                className="focus-ring hint-glow h-14 rounded-full bg-primary px-10 text-base font-bold text-primary-foreground shadow-lg shadow-primary/25 transition-all duration-150 hover:brightness-110 active:scale-95"
              >
                {t.getStarted} →
              </button>
              <p className="text-xs text-muted-foreground">{t.tourHint}</p>
            </div>
          </Reveal>
        </div>

        {/* Footer */}
        <Reveal className="mt-6 text-center" delay={100}>
          <p className="mx-auto max-w-md text-xs leading-relaxed text-muted-foreground">{t.footerText}</p>
          <p className="mt-3 text-[11px] font-semibold uppercase tracking-widest text-primary/70">
            {t.footerMark}
          </p>
          <p className="mt-1.5 text-[11px] font-medium text-muted-foreground">{t.copyright}</p>
        </Reveal>
      </div>
    </div>
  )
}

```


### `src/pages/Home.tsx`

```tsx
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router'
import {
  CHORDS,
  INSTRUMENTS,
  FAMILIES,
  chordName,
  fifthsLabel,
  keySpelling,
  minorKeySpelling,
  noteName,
  spellChordTones,
  transpose,
  type Instrument,
  type Spelling,
} from '@/lib/music'
import { cn } from '@/lib/utils'
import { Reveal } from '@/components/Reveal'
import { A11yPanel } from '@/components/A11yPanel'
import { StaffChord } from '@/components/StaffChord'
import { applyPrefs, loadPrefs, savePrefs, STRINGS, type A11yPrefs, type Strings } from '@/lib/a11y'

type Mode = 'major' | 'minor' | 'chord' | 'note'

const CHORD_GROUPS: { label: string; ids: string[] }[] = [
  { label: 'The basics', ids: ['power5', 'maj', 'min', 'sus2', 'sus4', 'aug'] },
  { label: 'Sevenths', ids: ['dom7', 'maj7', 'min7', 'min7b5', 'dim7'] },
  { label: 'Color chords', ids: ['six', 'add9', 'nine', 'min9', 'sevenflat9', 'thirteen'] },
]

function chordById(id: string) {
  return CHORDS.find((c) => c.id === id) ?? CHORDS[0]
}

function instById(id: string): Instrument | undefined {
  return INSTRUMENTS.find((i) => i.id === id)
}

/** Player colors — first come, first served, in the order players join the band. */
const PLAYER_COLORS = [
  '#b0551c', // burnt orange
  '#2e7d52', // green
  '#6b4fa1', // purple
  '#a12626', // red
  '#0f7b7b', // teal
  '#96711a', // gold-brown
  '#a13b72', // magenta
  '#465a8a', // steel blue
  '#7a4b1e', // brown
  '#3f7a3a', // olive
]
const SOURCE_COLOR = '#03339b' // royal blue — whoever leads

/** Colorblind-safe member marks: a distinct shape per join order, filled with the player's color. */
function MemberMark({ index, color }: { index: number; color: string }) {
  const cls = 'h-2.5 w-2.5 shrink-0'
  switch (index % 5) {
    case 0:
      return <span aria-hidden className={cn(cls, 'rounded-full')} style={{ backgroundColor: color }} />
    case 1:
      return <span aria-hidden className={cls} style={{ backgroundColor: color }} />
    case 2:
      return (
        <svg aria-hidden className={cls} viewBox="0 0 10 10">
          <path d="M5 0 10 10H0Z" fill={color} />
        </svg>
      )
    case 3:
      return (
        <svg aria-hidden className={cls} viewBox="0 0 10 10">
          <path d="M5 0 10 5 5 10 0 5Z" fill={color} />
        </svg>
      )
    default:
      return (
        <svg aria-hidden className={cls} viewBox="0 0 10 10">
          <path d="M0 8 5 0l5 8Z" fill="none" stroke={color} strokeWidth="2" />
        </svg>
      )
  }
}

// ── Small building blocks ─────────────────────────────────────────────

function NoteGrid({
  value,
  onChange,
  spelling,
}: {
  value: number
  onChange: (pc: number) => void
  spelling: Spelling
}) {
  return (
    <div className="grid grid-cols-4 gap-2 sm:grid-cols-6">
      {Array.from({ length: 12 }, (_, pc) => {
        const active = pc === value
        return (
          <button
            key={pc}
            type="button"
            onClick={() => onChange(pc)}
            aria-pressed={active}
            className={cn(
              'note-display focus-ring flex h-14 items-center justify-center rounded-md border text-lg font-semibold transition-all duration-150 active:scale-95',
              active
                ? 'border-primary bg-primary text-primary-foreground'
                : 'border-border bg-background text-foreground/80 hover:border-foreground/40 hover:text-foreground'
            )}
          >
            {noteName(pc, spelling)}
          </button>
        )
      })}
    </div>
  )
}

function Segmented<T extends string>({
  options,
  value,
  onChange,
  label,
}: {
  options: { value: T; label: string }[]
  value: T
  onChange: (v: T) => void
  label: string
}) {
  return (
    <div role="radiogroup" aria-label={label} className="flex rounded-md border border-border bg-card p-1">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            'focus-ring flex h-12 flex-1 items-center justify-center whitespace-nowrap rounded px-2 text-sm font-medium transition-all duration-150 active:scale-[0.97]',
            value === o.value
              ? 'bg-primary text-primary-foreground'
              : 'text-muted-foreground hover:text-foreground'
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}

function FieldLabel({ children, htmlFor }: { children: React.ReactNode; htmlFor?: string }) {
  return (
    <label
      htmlFor={htmlFor}
      className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground"
    >
      {children}
    </label>
  )
}

/** Tiny parenthetical that marks a tappable choice. */
function TapToChange({ t }: { t: Strings }) {
  return (
    <span aria-hidden className="mt-0.5 text-[10px] font-semibold uppercase tracking-widest text-primary">
      {t.tapToChange}
    </span>
  )
}

/** Numbered first-time instructions under a section heading. */
function HintSteps({ steps }: { steps: string[] }) {
  return (
    <ol className="mb-4 flex flex-col gap-1.5 rounded-lg border border-primary/20 bg-secondary/60 px-4 py-3">
      {steps.map((s, i) => (
        <li key={i} className="flex items-baseline gap-2 text-xs text-foreground/75">
          <span className="note-display shrink-0 text-[11px] font-bold text-primary">{i + 1}.</span>
          <span className="leading-snug">{s}</span>
        </li>
      ))}
    </ol>
  )
}

/** The leader's picker — sits inside the sentence. */
function InlineInstrumentSelect({
  id,
  value,
  onChange,
  t,
}: {
  id: string
  value: string
  onChange: (v: string) => void
  t: Strings
}) {
  return (
    <span className="inline-flex max-w-full flex-col items-center">
      <select
        id={id}
        aria-label={t.chooseInst}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="focus-ring select-chevron tap-select hint-glow h-12 max-w-full cursor-pointer rounded-md border px-3 text-base font-semibold transition-colors"
      >
        <option value="concert">Piano</option>
        {FAMILIES.map((f) => (
          <optgroup key={f.id} label={f.label}>
            {INSTRUMENTS.filter((i) => i.family === f.id).map((i) => (
              <option key={i.id} value={i.id}>
                {i.name}
                {i.key !== 'C' ? ` (${i.key})` : ''}
              </option>
            ))}
          </optgroup>
        ))}
      </select>
      <TapToChange t={t} />
    </span>
  )
}

/** A band member's own instrument picker — same tappable treatment. */
function MemberSelect({
  id,
  value,
  onChange,
  t,
}: {
  id: string
  value: string
  onChange: (v: string) => void
  t: Strings
}) {
  return (
    <span className="inline-flex max-w-full flex-col">
      <select
        id={id}
        aria-label={t.chooseInst}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="focus-ring select-chevron tap-select h-11 max-w-full cursor-pointer rounded-md border px-3 text-sm font-semibold transition-colors"
      >
        {FAMILIES.map((f) => (
          <optgroup key={f.id} label={f.label}>
            {INSTRUMENTS.filter((i) => i.family === f.id).map((i) => (
              <option key={i.id} value={i.id}>
                {i.name}
                {i.key !== 'C' ? ` (${i.key})` : ''}
              </option>
            ))}
          </optgroup>
        ))}
      </select>
      <TapToChange t={t} />
    </span>
  )
}

function ChordSelect({
  id,
  label,
  value,
  onChange,
  groups,
  t,
}: {
  id: string
  label?: string
  value: string
  onChange: (v: string) => void
  groups: { label: string; ids: string[] }[]
  t: Strings
}) {
  return (
    <div>
      {label && <FieldLabel htmlFor={id}>{label}</FieldLabel>}
      <select
        id={id}
        aria-label={label ?? t.chordType}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="focus-ring select-chevron tap-select h-12 cursor-pointer rounded-md border px-3 text-base font-semibold transition-colors"
      >
        {groups.map((g) => (
          <optgroup key={g.label} label={g.label}>
            {g.ids.map((cid) => {
              if (cid === 'key-major') return <option key={cid} value={cid}>Major key</option>
              if (cid === 'key-minor') return <option key={cid} value={cid}>Minor key</option>
              const c = chordById(cid)
              return (
                <option key={cid} value={cid}>
                  {c.label}
                  {c.suffix ? ` (${c.suffix})` : ''}
                </option>
              )
            })}
          </optgroup>
        ))}
      </select>
      {label && <TapToChange t={t} />}
    </div>
  )
}

function SpellingToggle({
  spelling,
  onChange,
  t,
}: {
  spelling: Spelling
  onChange: (s: Spelling) => void
  t: Strings
}) {
  return (
    <div className="flex items-center gap-1" role="radiogroup" aria-label={t.accidentalSpelling}>
      {(['flat', 'sharp'] as const).map((s) => (
        <button
          key={s}
          type="button"
          role="radio"
          aria-checked={spelling === s}
          onClick={() => onChange(s)}
          className={cn(
            'note-display focus-ring flex h-9 w-9 items-center justify-center rounded border text-sm font-bold transition-colors active:scale-95',
            spelling === s
              ? 'border-foreground/50 bg-secondary text-foreground'
              : 'border-border text-muted-foreground hover:text-foreground'
          )}
        >
          {s === 'flat' ? '♭' : '♯'}
        </button>
      ))}
    </div>
  )
}

function SectionHeading({ index, title, hint }: { index: string; title: string; hint?: string }) {
  return (
    <div className="mb-4 flex items-baseline gap-3">
      <span className="note-display text-xs font-semibold text-primary">{index}</span>
      <h2 className="font-serif text-xl font-semibold tracking-tight">{title}</h2>
      {hint && <p className="hidden text-xs text-muted-foreground sm:block">{hint}</p>}
    </div>
  )
}

/** Big answer display for any mode. */
function ResultText({
  pc,
  mode,
  chordId,
  spelling,
  big = false,
  t,
}: {
  pc: number
  mode: Mode
  chordId: string
  spelling: Spelling
  big?: boolean
  t: Strings
}) {
  if (mode === 'chord') {
    const c = chordById(chordId)
    return (
      <>
        <p className={cn('note-display font-extrabold leading-none tracking-tight', big ? 'text-6xl sm:text-7xl' : 'text-2xl')}>
          {chordName(pc, c, spelling)}
        </p>
        <p className={cn('note-display mt-2 text-muted-foreground', big ? 'text-base' : 'text-xs')}>
          {spellChordTones(pc, c, spelling).join(' · ')}
        </p>
      </>
    )
  }
  if (mode === 'note') {
    return (
      <p className={cn('note-display font-extrabold leading-none tracking-tight', big ? 'text-6xl sm:text-7xl' : 'text-2xl')}>
        {noteName(pc, spelling)}
      </p>
    )
  }
  const k = mode === 'major' ? keySpelling(pc) : minorKeySpelling(pc)
  return (
    <>
      <p className={cn('note-display font-extrabold leading-none tracking-tight', big ? 'text-6xl sm:text-7xl' : 'text-2xl')}>
        {k.name}
      </p>
      <p className={cn('note-display mt-2 text-muted-foreground', big ? 'text-base' : 'text-xs')}>
        {mode === 'major' ? t.majorKeyWord : t.minorKeyWord} {t.keyWord} · {'tie' in k && k.tie ? t.tieLabel : fifthsLabel(k.fifths)}
      </p>
    </>
  )
}

// ── Page ──────────────────────────────────────────────────────────────

interface Player {
  uid: number
  instrumentId: string
}

const CHORD_TONE_LABELS: Record<number, string> = {
  0: 'root', 2: '2nd / 9th', 3: 'minor 3rd', 4: 'major 3rd', 5: '4th / 11th',
  6: '♭5 / ♯11', 7: '5th', 8: '♯5 / ♭13', 9: '6th / 13th', 10: '♭7', 11: 'major 7',
}

const TONE_SHORT: Record<number, string> = {
  0: 'R', 2: '2', 3: '♭3', 4: '3', 5: '4', 6: '♭5', 7: '5', 8: '♭6', 9: '6', 10: '♭7', 11: '7',
}

/** Can this player actually play a stacked chord, or do they take one note? */
function isChordPlayer(inst: Instrument): boolean {
  return inst.family === 'keys' || inst.family === 'strings'
}

function defaultToneFor(inst: Instrument): number {
  if (inst.id === 'vox-lead' || inst.id === 'vox-s') return 0
  if (inst.id === 'vox-a' || inst.id === 'sax-alto' || inst.id === 'tpt-bb') return 4
  if (inst.id === 'sax-tenor') return 7
  if (inst.id === 'sax-bari' || inst.id === 'vox-b' || inst.id === 'bass-gtr') return 10
  return 4
}

export default function Home() {
  const [prefs, setPrefsState] = useState<A11yPrefs>(() => loadPrefs())
  const t = STRINGS[prefs.lang]
  function setPrefs(next: A11yPrefs) {
    setPrefsState(next)
    savePrefs(next)
  }
  useEffect(() => {
    applyPrefs(prefs)
  }, [prefs])

  const [spelling, setSpelling] = useState<Spelling>('flat')

  // ── 01 The source: whoever leads (piano by default) sets the key ──
  const [sourceId, setSourceId] = useState('concert')
  const [pc, setPc] = useState(9) // A
  const [mode, setMode] = useState<Mode>('major')
  const [chordId, setChordId] = useState('nine')

  // ── 02 The band — first member is the tenor sax, add without limit ──
  const [members, setMembers] = useState<Player[]>([{ uid: 1, instrumentId: 'sax-tenor' }])
  const uidRef = useRef(2)
  const [addId, setAddId] = useState('vox-lead')
  const [tones, setTones] = useState<Record<number, number>>({})

  const sourceInst = sourceId === 'concert' ? undefined : instById(sourceId)
  const concertPc = sourceInst ? transpose(pc, sourceInst, false) : pc

  // Effective chord for this mode (note mode = single tone, key modes = triad on the staff)
  const bandChord = mode === 'chord' ? chordById(chordId) : mode === 'minor'
    ? chordById('min') : mode === 'major' ? chordById('maj') : chordById('maj')
  const intervals = mode === 'note' ? [0] : bandChord.intervals
  const toneOptions = intervals.map((i) => i % 12)

  function toneFor(uid: number, inst: Instrument): number {
    const assigned = tones[uid]
    if (assigned !== undefined && toneOptions.includes(assigned)) return assigned
    const def = defaultToneFor(inst)
    return toneOptions.includes(def) ? def : toneOptions[0]
  }

  const nameCounts = useMemo(() => {
    const counts = new Map<string, number>()
    members.forEach((p) => counts.set(p.instrumentId, (counts.get(p.instrumentId) ?? 0) + 1))
    return counts
  }, [members])

  function memberLabel(p: Player): string {
    const inst = instById(p.instrumentId)
    const base = inst?.name ?? p.instrumentId
    if ((nameCounts.get(p.instrumentId) ?? 0) <= 1) return base
    const idx = members.filter((q) => q.instrumentId === p.instrumentId).findIndex((q) => q.uid === p.uid)
    return `${base} #${idx + 1}`
  }

  const colorFor = (index: number) => PLAYER_COLORS[index % PLAYER_COLORS.length]

  function addMember() {
    setMembers((ps) => [...ps, { uid: uidRef.current++, instrumentId: addId }])
  }

  function removeMember(uid: number) {
    setMembers((ps) => ps.filter((p) => p.uid !== uid))
  }

  function changeMember(uid: number, instrumentId: string) {
    setMembers((ps) => ps.map((p) => (p.uid === uid ? { ...p, instrumentId } : p)))
  }

  // ── Staff data: concert chord, each tone colored by its owner ──
  const staffTones = intervals.map((s) => {
    const ownerIdx = members.findIndex((p) => {
      const inst = instById(p.instrumentId)
      return inst && !isChordPlayer(inst) && toneFor(p.uid, inst) === s % 12
    })
    if (ownerIdx >= 0) {
      return { semitones: s, color: colorFor(ownerIdx), label: memberLabel(members[ownerIdx]) }
    }
    return { semitones: s, color: 'hsl(var(--muted-foreground))', label: '' }
  })
  const chordPlayersInBand = members.filter((p) => {
    const inst = instById(p.instrumentId)
    return inst && isChordPlayer(inst)
  })
  const staffBracketLabel = [
    sourceInst ? undefined : 'Piano',
    ...chordPlayersInBand.map((p) => memberLabel(p)),
  ].filter(Boolean).join(' · ') || undefined

  return (
    <div className="min-h-dvh">
      <div className="grain" aria-hidden />
      <div className="mx-auto w-full max-w-2xl px-4 pb-16 sm:px-6">
        {/* Header */}
        <header className="relative flex items-center justify-center border-b border-border py-5">
          <div className="absolute left-0 flex items-center gap-2">
            <Link
              to="/"
              className="focus-ring flex h-11 items-center gap-1 rounded-full border border-border bg-card px-3 text-xs font-semibold text-foreground shadow-sm transition-colors hover:border-primary hover:text-primary"
              aria-label="Back to home"
            >
              ← <span className="hidden sm:inline">Home</span>
            </Link>
            <span className="hidden items-center gap-1.5 rounded-full border border-primary/25 bg-secondary px-2.5 py-1 md:flex">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" aria-hidden />
              <span className="text-[10px] font-semibold uppercase tracking-wider text-secondary-foreground">{t.offlineReady}</span>
            </span>
          </div>
          <div className="absolute right-0">
            <A11yPanel prefs={prefs} setPrefs={setPrefs} t={t} />
          </div>
          <div className="flex items-center gap-2.5">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden className="text-primary">
              <path d="M9 18V5l12-2v13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="6" cy="18" r="3" stroke="currentColor" strokeWidth="2" />
              <circle cx="18" cy="16" r="3" stroke="currentColor" strokeWidth="2" />
            </svg>
            <span className="font-serif text-lg font-semibold tracking-tight">{t.appName}</span>
          </div>
        </header>

        {/* Hero */}
        <div className="relative overflow-hidden">
          <div
            aria-hidden
            className="kenburns pointer-events-none absolute -inset-10"
            style={{
              background:
                'radial-gradient(42% 55% at 22% 18%, hsl(223 90% 88% / 0.9), transparent 70%), radial-gradient(38% 48% at 82% 30%, hsl(221 96% 31% / 0.14), transparent 70%), radial-gradient(50% 42% at 50% 88%, hsl(41 60% 80% / 0.55), transparent 72%)',
            }}
          />
          <Reveal className="relative pb-6 pt-8 text-center">
            <h1 className="font-serif text-2xl font-semibold leading-tight tracking-tight sm:text-3xl">
              {t.heroTitleA}
              <br />
              {t.heroTitleB}
            </h1>
            <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
              {t.heroSub}
            </p>
          </Reveal>
        </div>

        {/* ── 01 Set the key ── */}
        <section aria-labelledby="source" className="mb-12">
          <Reveal>
            <SectionHeading index="01" title={t.s1Title} hint={t.s1Hint} />
            <HintSteps steps={t.s1Steps} />
          </Reveal>
          <Reveal delay={80}>
            <div className="rounded-lg border border-border bg-card p-4 shadow-sm sm:p-6">
              <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
                <span className="font-serif text-xl font-medium sm:text-2xl">{t.ifThe}</span>
                <InlineInstrumentSelect id="source-inst" value={sourceId} onChange={setSourceId} t={t} />
                <span className="font-serif text-xl font-medium sm:text-2xl">
                  {sourceInst && sourceInst.family === 'voice' ? t.isSinging : t.isPlaying}
                </span>
              </div>

              <div className="mt-4 flex flex-col gap-4">
                <Segmented
                  label={t.whatPlaying}
                  value={mode}
                  onChange={setMode}
                  options={[
                    { value: 'major', label: t.majorKey },
                    { value: 'minor', label: t.minorKey },
                    { value: 'chord', label: t.chord },
                    { value: 'note', label: t.note },
                  ]}
                />

                {mode === 'chord' && (
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
                    <span className="font-serif text-xl font-medium sm:text-2xl">{t.a}</span>
                    <ChordSelect id="chord-quality" value={chordId} onChange={setChordId} groups={CHORD_GROUPS} t={t} />
                    <span className="font-serif text-xl font-medium sm:text-2xl">{t.on}</span>
                  </div>
                )}

                <div>
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      {sourceInst
                        ? `${sourceInst.name}${mode === 'note' ? t.writtenNoteLabel : t.writtenRoot}`
                        : mode === 'note'
                          ? t.theNote
                          : t.rootKeyOfMusic}
                    </span>
                    <SpellingToggle spelling={spelling} onChange={setSpelling} t={t} />
                  </div>
                  <NoteGrid value={pc} onChange={setPc} spelling={spelling} />
                </div>
              </div>

              {/* Source banner */}
              <div className="mt-5 flex items-center gap-3 rounded-md bg-primary px-4 py-3 text-primary-foreground">
                <MemberMark index={0} color="hsl(var(--primary-foreground))" />
                <p className="text-sm font-semibold">
                  {t.sourcePrefix}{' '}
                  {sourceInst
                    ? `${sourceInst.name}${sourceInst.key !== 'C' ? ` · ${t.inKey} ${sourceInst.key}` : ''}${t.sourcePlayerSuffix}`
                    : t.sourcePianoText}
                </p>
              </div>
            </div>
          </Reveal>
        </section>

        {/* ── 02 The band plays ── */}
        <section aria-labelledby="band">
          <Reveal>
            <SectionHeading index="02" title={t.s2Title} hint={t.s2Hint} />
            <HintSteps steps={t.s2Steps} />
          </Reveal>
          <Reveal delay={80}>
            <div className="rounded-lg border border-border bg-card p-4 shadow-sm sm:p-6">
              {/* Members */}
              <div>
                {members.map((p, index) => {
                  const inst = instById(p.instrumentId)
                  if (!inst) return null
                  const color = colorFor(index)
                  const chordPlayer = isChordPlayer(inst)
                  const singleNote = !chordPlayer
                  const tone = toneFor(p.uid, inst)
                  const noteOut = transpose((concertPc + tone) % 12, inst, true)
                  const chordOut = transpose(concertPc, inst, true)
                  return (
                    <div key={p.uid} className="border-b border-border/60 py-4 first:pt-0 last:border-b-0">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2.5">
                            <MemberMark index={index} color={color} />
                            <MemberSelect
                              id={`member-${p.uid}`}
                              value={p.instrumentId}
                              onChange={(v) => changeMember(p.uid, v)}
                              t={t}
                            />
                            {inst.key !== 'C' && (
                              <span className="note-display shrink-0 rounded border border-border px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground">
                                {inst.key}
                              </span>
                            )}
                          </div>
                          <div
                            key={`${p.instrumentId}-${concertPc}-${mode}-${chordId}-${tone}-${spelling}`}
                            className={cn('answer-pop mt-2 pl-[18px]', inst.offset % 12 === 0 ? 'text-foreground/70' : 'text-primary')}
                          >
                            {singleNote && mode === 'chord' ? (
                              <>
                                {/* A horn doesn't play "E9" — it plays ONE note. Lead with that. */}
                                <p className="note-display text-2xl font-extrabold leading-none tracking-tight">
                                  {noteName(noteOut, spelling)}
                                </p>
                                <p className="note-display mt-2 text-xs text-muted-foreground">
                                  {t.yourNoteLineA} {noteName(noteOut, spelling)} — {t.theWord} {TONE_SHORT[tone] ?? tone} {t.ofTheChord}{' '}
                                  {chordName(chordOut, chordById(chordId), spelling)}
                                </p>
                                <p className="note-display mt-1 text-xs font-medium text-foreground/80">
                                  {t.pianoPlays}{' '}
                                  {noteName((concertPc + tone) % 12, spelling)}
                                </p>
                              </>
                            ) : (
                              <ResultText pc={chordOut} mode={mode} chordId={chordId} spelling={spelling} t={t} />
                            )}
                            {singleNote && mode !== 'chord' && mode !== 'note' && (
                              <p className="note-display mt-1 text-xs text-muted-foreground">
                                {t.writtenNoteOfChord}: {noteName(noteOut, spelling)} · {TONE_SHORT[tone] ?? tone} {t.ofTheChord} ·{' '}
                                {t.pianoPlays} {noteName((concertPc + tone) % 12, spelling)}
                              </p>
                            )}
                          </div>
                          {singleNote && toneOptions.length > 1 && (
                            <div className="mt-2 pl-[18px]">
                              <label htmlFor={`tone-${p.uid}`} className="sr-only">
                                {memberLabel(p)}
                              </label>
                              <select
                                id={`tone-${p.uid}`}
                                value={tone}
                                onChange={(e) => setTones((tt) => ({ ...tt, [p.uid]: Number(e.target.value) }))}
                                className="focus-ring select-chevron tap-select h-11 cursor-pointer rounded-md border px-3 text-sm font-medium transition-colors"
                              >
                                {toneOptions.map((tonePc) => (
                                  <option key={tonePc} value={tonePc}>
                                    {t.playsThe} {CHORD_TONE_LABELS[tonePc] ?? tonePc}
                                  </option>
                                ))}
                              </select>
                            </div>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => removeMember(p.uid)}
                          aria-label={`Remove ${memberLabel(p)}`}
                          className="focus-ring flex h-11 w-11 shrink-0 items-center justify-center rounded-md border border-border text-muted-foreground transition-all duration-150 hover:border-destructive hover:text-destructive active:scale-95"
                        >
                          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
                            <path d="M1 1l12 12M13 1L1 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>

              {/* Add member */}
              <div className="mt-5 flex flex-col gap-3 border-t border-border pt-5 sm:flex-row sm:items-end">
                <div className="flex-1">
                  <FieldLabel htmlFor="add-player">{t.addLabel}</FieldLabel>
                  <select
                    id="add-player"
                    value={addId}
                    onChange={(e) => setAddId(e.target.value)}
                    className="focus-ring select-chevron tap-select h-14 w-full cursor-pointer rounded-md border px-4 text-base font-medium transition-colors"
                  >
                    {FAMILIES.map((f) => (
                      <optgroup key={f.id} label={f.label}>
                        {INSTRUMENTS.filter((i) => i.family === f.id).map((i) => (
                          <option key={i.id} value={i.id}>
                            {i.name}
                            {i.key !== 'C' ? ` (${i.key})` : ''}
                          </option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                  <TapToChange t={t} />
                </div>
                <button
                  type="button"
                  onClick={addMember}
                  className="focus-ring hint-glow h-14 shrink-0 rounded-md bg-primary px-6 text-sm font-bold text-primary-foreground transition-all duration-150 hover:brightness-110 active:scale-95"
                >
                  {t.addPlayer}
                </button>
              </div>

              {/* The band on the staff */}
              <div className="mt-6 rounded-lg border border-primary/20 bg-background p-4 sm:p-5">
                <p className="mb-3 font-serif text-base font-semibold tracking-tight">{t.staffTitle}</p>
                <StaffChord
                  rootPc={concertPc}
                  intervals={intervals}
                  tones={staffTones}
                  bracketColor={SOURCE_COLOR}
                  bracketLabel={staffBracketLabel}
                  t={t}
                />
              </div>
            </div>
          </Reveal>
        </section>

        {/* Footer */}
        <Reveal className="mt-10 text-center" delay={100}>
          <p className="mx-auto max-w-md text-xs leading-relaxed text-muted-foreground">{t.footerText}</p>
          <p className="mt-3 text-[11px] font-semibold uppercase tracking-widest text-primary/70">
            {t.footerMark}
          </p>
          <p className="mt-1.5 text-[11px] font-medium text-muted-foreground">{t.copyright}</p>
        </Reveal>
      </div>
    </div>
  )
}

```


### `src/index.css`

```css
@import './fonts.css';

@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    /* Warm ivory paper — church hymnal feel */
    --background: 44 38% 95%;
    --foreground: 35 22% 16%;
    --card: 45 40% 98%;
    --card-foreground: 35 22% 16%;
    --popover: 45 40% 98%;
    --popover-foreground: 35 22% 16%;
    /* Deep royal blue — stained-glass sapphire */
    --primary: 221 96% 31%;
    --primary-foreground: 44 38% 97%;
    /* Light blue tint — highlighted, tappable surfaces */
    --secondary: 223 72% 94%;
    --secondary-foreground: 221 60% 25%;
    --muted: 42 24% 90%;
    --muted-foreground: 36 12% 40%;
    --accent: 221 96% 31%;
    --accent-foreground: 44 38% 97%;
    --destructive: 4 56% 42%;
    --destructive-foreground: 44 38% 97%;
    --border: 40 22% 82%;
    --input: 40 22% 82%;
    --ring: 221 96% 31%;
    --radius: 0.5rem;
  }

  /* Dark mode — evening service */
  .dark {
    --background: 226 32% 10%;
    --foreground: 44 30% 92%;
    --card: 226 26% 15%;
    --card-foreground: 44 30% 92%;
    --popover: 226 26% 15%;
    --popover-foreground: 44 30% 92%;
    --primary: 220 85% 62%;
    --primary-foreground: 226 40% 8%;
    --secondary: 222 30% 22%;
    --secondary-foreground: 220 70% 88%;
    --muted: 226 20% 20%;
    --muted-foreground: 40 12% 62%;
    --accent: 220 85% 62%;
    --accent-foreground: 226 40% 8%;
    --destructive: 4 60% 55%;
    --destructive-foreground: 44 30% 95%;
    --border: 224 20% 26%;
    --input: 224 20% 26%;
    --ring: 220 85% 62%;
  }
}

@layer base {
  * {
    @apply border-border;
  }
  html {
    color-scheme: light;
    scroll-behavior: smooth;
  }
  body {
    @apply bg-background text-foreground font-sans antialiased;
  }
  ::selection {
    background: hsl(var(--primary));
    color: hsl(var(--primary-foreground));
  }
}

@layer utilities {
  .note-display {
    font-family: 'JetBrains Mono', ui-monospace, monospace;
    font-variant-numeric: tabular-nums;
  }
  .font-serif-display {
    font-family: 'Fraunces', Georgia, serif;
    font-optical-sizing: auto;
  }
  .focus-ring {
    @apply focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background;
  }

  /* ── Tappable selects: blue tint + chevron + soft beckoning glow ── */
  .select-chevron {
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%231a2fa0' stroke-width='3' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 0.7rem center;
    padding-right: 2.4rem;
  }
  .tap-select {
    @apply border-primary/45 bg-secondary text-secondary-foreground shadow-sm;
  }
  .tap-select:hover {
    @apply border-primary brightness-[1.02];
  }
  .hint-glow {
    animation: hint-glow 2.6s ease-in-out infinite;
  }
  .ease-reveal {
    transition-timing-function: cubic-bezier(0.22, 1, 0.36, 1);
  }
}

/* ── Signature motion ─────────────────────────────────────────────── */

/* Ken Burns — slow cinematic drift on the hero wash */
@keyframes kenburns {
  0% {
    transform: scale(1) translate(0, 0);
  }
  100% {
    transform: scale(1.08) translate(-1.5%, -2%);
  }
}
.kenburns {
  animation: kenburns 30s ease-in-out infinite alternate;
  will-change: transform;
}

/* Golden notes drifting upward like dust motes in window light */
@keyframes drift-up {
  0% {
    transform: translateY(24px) scale(0.85) rotate(-4deg);
    opacity: 0;
  }
  12% {
    opacity: 0.75;
  }
  70% {
    opacity: 0.55;
  }
  100% {
    transform: translateY(-280px) scale(1.05) rotate(6deg);
    opacity: 0;
  }
}
.float-note {
  position: absolute;
  bottom: 0;
  opacity: 0;
  animation: drift-up linear infinite;
  will-change: transform, opacity;
}

/* The answer settles in with a soft blur-pop whenever it changes */
@keyframes answer-pop {
  0% {
    opacity: 0;
    transform: scale(0.92);
    filter: blur(8px);
  }
  60% {
    filter: blur(0);
  }
  100% {
    opacity: 1;
    transform: scale(1);
    filter: blur(0);
  }
}
.answer-pop {
  animation: answer-pop 0.5s cubic-bezier(0.22, 1, 0.36, 1) both;
  transform-origin: center;
}

/* Gentle beckoning ring on the inline instrument pickers */
@keyframes hint-glow {
  0%,
  100% {
    box-shadow: 0 0 0 0 hsl(221 96% 31% / 0.28);
  }
  50% {
    box-shadow: 0 0 0 6px hsl(221 96% 31% / 0);
  }
}

/* Fine film grain over the whole page — analog warmth */
.grain {
  position: fixed;
  inset: 0;
  z-index: 60;
  pointer-events: none;
  opacity: 0.05;
  mix-blend-mode: multiply;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
}

/* ── SCN accessibility modes ──────────────────────────────────────── */

/* Calm mode: stop all decorative motion (same effect as reduced-motion) */
.calm .kenburns,
.calm .float-note,
.calm .answer-pop,
.calm .hint-glow {
  animation: none !important;
}
.calm .float-note {
  display: none;
}
.calm * {
  transition-duration: 0.01ms !important;
}
.calm html {
  scroll-behavior: auto;
}

/* Large text */
.large-text body {
  font-size: 18px;
}
.large-text .note-display.text-6xl {
  font-size: 4.5rem;
}

/* Colorblind-friendly: bold outlines on every selection, so meaning never
   rides on color alone */
.a11y-cb [aria-pressed='true'],
.a11y-cb [aria-checked='true'] {
  outline: 3px solid hsl(var(--foreground)) !important;
  outline-offset: 1px;
}

/* Grain respects dark mode */
.dark .grain {
  mix-blend-mode: screen;
  opacity: 0.06;
}

@media (prefers-reduced-motion: reduce) {
  html {
    scroll-behavior: auto;
  }
  .kenburns,
  .float-note,
  .answer-pop,
  .hint-glow {
    animation: none !important;
  }
  .float-note {
    display: none;
  }
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}

```


### `src/fonts.css`

```css
@font-face {
  font-family: 'Fraunces';
  font-style: normal;
  font-display: swap;
  font-weight: 400 600;
  font-display: swap;
  src: url(../fonts/fraunces-latin.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
@font-face {
  font-family: 'JetBrains Mono';
  font-style: normal;
  font-display: swap;
  font-weight: 500 800;
  font-display: swap;
  src: url(../fonts/jetbrainsmono-latin.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
@font-face {
  font-family: 'Work Sans';
  font-style: normal;
  font-display: swap;
  font-weight: 400 700;
  font-display: swap;
  src: url(../fonts/worksans-latin.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
```


### `public/sw.js`

```js
/* Transpose — offline-first service worker.
   Strategy: precache the app shell on install; serve cache-first for same-origin
   GET requests; fall back to the cached index.html for navigations. */
const VERSION = 'transpose-v3';

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(VERSION);
      // Precache the entry page; everything else is cached at runtime on first fetch.
      await cache.add(new Request('./', { cache: 'reload' }));
      self.skipWaiting();
    })()
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)));
      await self.clients.claim();
    })()
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    (async () => {
      const cache = await caches.open(VERSION);
      const cached = await cache.match(request, { ignoreSearch: false });
      if (cached) return cached;
      try {
        const response = await fetch(request);
        if (response.ok) {
          // Cache same-origin assets (JS, CSS, fonts, icons, demo video) for offline use.
          cache.put(request, response.clone());
        }
        return response;
      } catch (err) {
        // Offline and not cached: if it's a page navigation, serve the app shell.
        if (request.mode === 'navigate') {
          const shell = await cache.match('./');
          if (shell) return shell;
        }
        throw err;
      }
    })()
  );
});

```


### `public/manifest.webmanifest`

```json
{
  "name": "Transpose — Instrument & Voice Transposer",
  "short_name": "Transpose",
  "description": "The piano is a C instrument. Its key is the key of the music. See what every instrument and voice plays from there — works fully offline.",
  "id": "./",
  "start_url": "./",
  "scope": "./",
  "display": "standalone",
  "orientation": "portrait",
  "background_color": "#f6f2e8",
  "theme_color": "#03339b",
  "lang": "en",
  "categories": ["music", "education", "utilities"],
  "icons": [
    { "src": "icons/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "icons/icon-512.png", "sizes": "512x512", "type": "image/png" },
    { "src": "icons/maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ]
}

```


### `vercel.json`

```json
{
  "$schema": "https://openapi.vercel.sh/vercel.json",
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite",
  "headers": [
    {
      "source": "/sw.js",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "no-cache"
        }
      ]
    },
    {
      "source": "/assets/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=31536000, immutable"
        }
      ]
    }
  ],
  "rewrites": [
    {
      "source": "/((?!assets|icons|fonts|demo.mp4|manifest.webmanifest|sw.js|favicon.*).*)",
      "destination": "/index.html"
    }
  ]
}
```

---
## 6. The demo video recipe (SCN standard — memorize, reuse for every demo)

1. Serve the built app: `python3 -m http.server 8123 -d dist` (relaunch between shell calls — the server dies).
2. Playwright (async) records a REAL run: viewport 390×720, deviceScaleFactor 2, `record_video_dir` + `record_video_size`.
3. Before recording, inject an overlay: a 30 px finger dot (royal-blue ring `rgba(26,47,160,.85)`, cubic-bezier movement, press scale-down) + a bottom caption pill (`#03339b` bg, cream text, rounded-full) that narrates each step. **Hide the landing page's own video element first** or you get video-in-video.
4. Script the real user flow with ~1.5–5 s beats so every action reads: landing → Get started → the sentence → tap a key → switch to Chord (9th) → the band (tenor) → add a singer + trumpet → scroll to the staff → change a horn's chord tone → SCN sign-off. Target ~65 s so it covers the full song.
5. Close the CONTEXT (not the browser) to finalize the `.webm`.
6. Encode phone-safe (this profile is MANDATORY — without it iPhones show a blank box):
   `ffmpeg -ss 1.3 -i in.webm -i song.wav -filter:v "tpad=stop_mode=clone:stop=10" -t 67.6 -c:v libx264 -profile:v baseline -level 3.1 -pix_fmt yuv420p -crf 28 -c:a aac -b:a 128k -movflags +faststart out.mp4`
   (`-ss 1.3` trims the first-frame white flash; `tpad` clones the last frame so the FULL 67.6 s song plays; current track: **"Every Voice, One Answer"** — Suno, 92 BPM gospel trap.)
7. Embed on the landing top, `autoPlay loop playsInline preload="auto"` (no `controls`, no mute toggle) + the autoplay hook in `Landing.tsx`.

## 7. Acceptance tests (all must pass after rebuild)

1. Piano in A major → tenor sax reads **B** major · 5 sharps; alto sax reads F♯/G♭ tie; lead vocal reads A.
2. Chord mode: 9th chord spells correctly for every root (no wrong letters).
3. Add players without limit; two of the same instrument number #1/#2; colors follow join order.
4. Staff: correct treble clef, noteheads colored by owner, ♯/♭ accidentals, ledger lines, blue whole-chord bracket.
5. A11y: calm kills motion, large text 18 px, dark theme, ES switch persists after reload, colorblind adds shapes + outlines.
6. PWA: cut the network after first load → app still works, demo video still plays (precached).
7. Zero console errors on mobile 390 px and desktop 1440 px.

## 8. Known gaps — requested but NOT yet built (the next session's work)

From the user's latest review (these are the active TODOs, in priority order):

1. **Horn language / piano cross-reference** — horns should not see raw "E9"-style output; each horn's note should read as "the [3rd/5th/…] of the piano's [chord]" and show **where on the piano** that note sits (e.g. 4th octave), so the horn player and pianist speak the same language and band arguments stop. The app must speak EVERY musician's language.
2. **Demo video mismatch** — the current demo still shows older fragments; re-record it against the unified flow (recipe above) so it shows band + staff (and later the draggable overlay).
3. **47+ languages via a free translation API** (MyMemory / similar; GetWell used free APIs) with a GetWell-style glass picker and an "Auto-translated • may contain errors" notice — beyond the current hand-built en/es tables.
4. **Full SCN Universal Access panel** modeled on https://supercodingninja.github.io/GetWell/ — categories with toggles: Neurodivergent (Autism-calm, ADHD-focus, Dyslexia font, Dyspraxia), Mental Health (Anxiety relief, PTSD no-flash, Bipolar/Mania support, Cognitive load), Vision (Screen reader mode, High contrast, + 7 color-vision filters via SVG feColorMatrix: deuteranomaly/deuteranopia/protanomaly/protanopia/tritanomaly/tritanopia/achromatopsia), Hearing (Visual alerts, Captions always on), Motor & Physical (Large targets, Keyboard-only, Extended time, Switch control), Speech (Simplified language). Reference: the GetWell modal markup/CSS is on that page.
5. **Slide-over translucent menu** (blurred-backdrop overlay, X to close) to compress the long page so there's less scrolling.
6. **Draggable translucent staff overlay** — the staff ("stanza") floats translucently and the user can drag it anywhere over the page; show this in the demo.
7. Keep all existing visuals (ivory/royal blue, Ken Burns, floating notes) — "I like it the way it looks… there's just gotta be a better way."

## 9. Delivery rules (standing orders from the owner)

- **ALWAYS show the app through the viewer** — save every change with the version manager so the preview card appears. No exceptions.
- Deliver GitHub-ready zips (no `node_modules`, no `dist`) for phone-only upload; Vercel hosts it at **transpose.scn.ninja** (CNAME `transpose` → `cname.vercel-dns.com`).
- The owner works ONLY from iPhone/iPad — no npm on his end; Vercel builds in the cloud.
- Copyright on every page: "Built by SCN Technologies — accessible by design." + "© 2026 SCN Technologies. All rights reserved."
- Music autoplay is the owner's explicit call; never re-add mute toggles or sound buttons.
- Assets: `public/demo.mp4` (67.6 s, baseline H.264 + AAC 128k), `public/icons/` (PIL-generated royal-blue/ivory), `public/fonts/` (self-hosted woff2). These binary assets are NOT in this PRD — pull them from the latest `transpose-app.zip`.
